# Local Deployment

## How the site works

This is a Vite + React website with hash routing. The visible menu now contains only **Home**, **B2B Deals**, **Gallery**, and **Contact**.

The project is no longer intended to be served only as a static folder when inquiry saving is required. The local Node server serves the built `docs/` website and handles `POST /api/inquiries`.

When a user submits the B2B form, the server creates or updates:

```text
inquiries/inquiries.xlsx
```

The workbook contains one `Inquiries` sheet with the following columns:

| Date | Time | Name | Company / Shop | Phone / WhatsApp | Email | Brands / Products Interested In | Message / Requirements |
|---|---|---|---|---|---|---|---|

The date and time are recorded on the computer running the server. After a successful save, the form shows a green checkmark and the message **“Inquiry Received”** followed by **“A dedicated person will contact you soon.”**

## Run locally on Windows

Install Node.js LTS and confirm that Node and npm are available:

```powershell
node --version
npm --version
```

Open PowerShell in the folder containing `package.json`, then install dependencies and start the website:

```powershell
npm install
npm run build
npm start
```

The first time, build the website once, then start the server:

```powershell
npm run build
npm start
```

The normal `npm start` command now launches the already-built website without rebuilding it, so restarts are much faster. After source-code changes, run `npm run build` again before restarting.

The server normally runs at:

```text
http://localhost:5000
```

Keep this server running while the website is in use. The `inquiries` folder is created automatically after the first successful B2B submission.

## Development mode

For frontend editing with Vite hot reload, run:

```powershell
npm run dev -- --host 0.0.0.0
```

The development server includes the same `/api/inquiries` endpoint, so B2B form testing works during development as well.

## Important deployment note

A static-only server such as `npx serve docs -l 5000` can display the website but cannot write inquiry data to the computer. Use `npm start` whenever the B2B Excel-saving feature is required.

For Cloudflare Tunnel, point the tunnel to the same port used by the Node server:

```powershell
cloudflared tunnel --url http://localhost:5000
```

Start `npm start` first, then start the tunnel. If you changed source files, stop the server, run `npm run build`, start `npm start` again, and keep the tunnel pointed at port 5000.

## Main files

| File | Purpose |
|---|---|
| `src/App.tsx` | Defines the active routes. |
| `src/components/Nav.tsx` | Defines the four-item menu order. |
| `src/pages/B2B.tsx` | Contains the B2B enquiry form and success/error states. |
| `server/inquiry-store.mjs` | Creates and appends records to `inquiries/inquiries.xlsx`. |
| `server.mjs` | Serves the production website and handles the inquiry API. |
| `vite.config.js` | Adds the inquiry API to the Vite development server. |
| `package.json` | Includes the `npm start` command. |

## Verification checklist

| Check | Expected result |
|---|---|
| `npm run build` | Completes successfully and writes `docs/`. |
| Menu | Shows Home, B2B Deals, Gallery, Contact in that order. |
| Price List | No longer appears as a route, menu item, or build feature. |
| B2B submission | Creates or appends to `inquiries/inquiries.xlsx`. |
| Excel record | Includes date, time, and all submitted form fields. |
| Success message | Displays a green checkmark and confirmation text. |
| Invalid submission | Shows the form validation messages and does not save a row. |

## Performance notes

The old accessories spreadsheet parser and Price List data pipeline have been removed. The B2B Excel inquiry store remains because it is still an active feature.

The initial homepage JavaScript is now split from the B2B, Gallery, Contact, and Raksha Bandhan page chunks. Secondary page code loads only when its route is opened. Hashed assets are served with long-lived cache headers, while `index.html` remains non-cached so new deployments are detected.

For a fast restart, use:

```powershell
npm start
```

For a source-code update, use:

```powershell
npm run build
npm start
```

## Gallery folders

The Gallery reads the connected GitHub `gallery/` directory recursively. Root-level images appear under **All Pictures**. Any real subfolder, such as `rakshabandhan`, is automatically displayed below All Pictures with its own image count. Selecting a folder filters the gallery to that folder, while All Pictures combines root-level and nested-folder images.

Use standard image files such as PNG, JPG, JPEG, GIF, WEBP, or SVG. Avoid adding generated-icon files if they should not appear in the public gallery.

## Master gallery panel

The private gallery manager is available at:

```text
/master
```

The initial credential file is created at:

```text
master/credentials.txt
```

Its format is:

```text
id=master
password=change-this-password
```

Change the password in this file before exposing the site through a public Cloudflare Tunnel. The server reads the file when authentication is attempted. Successful login creates an expiring HttpOnly session cookie; the credential file is never sent to the browser.

After login, the Master panel supports creating folders, choosing an upload destination, selecting multiple images from a mobile device, and deleting individual gallery images. Supported image formats are PNG, JPG, JPEG, GIF, WEBP, and SVG, with a 12 MB limit per image. Uploaded files are stored in the website’s `gallery/` folder and immediately appear on the public Gallery page through `/api/gallery`.

Do not use a static-only server for the Master panel. Run the Node server with `npm start`, then expose the same port through Cloudflare Tunnel.

## Master folder inventory

The Master Panel now scans the complete `gallery` directory on the PC whenever the gallery inventory is requested. It lists every existing subfolder, including folders with zero images, and separately lists every supported image found recursively inside those folders. Empty folders are marked **Empty** and can immediately be selected as upload destinations.

## Master upload behavior

Creating a folder now performs a fresh server inventory scan before selecting it as the upload destination, so the new folder appears immediately in both the destination selector and Existing folders list.

The upload control no longer requests camera capture. It uses the normal image chooser with multiple selection enabled. On iPhone or Android, the operating system/browser will show its available Photos, Photo Library, or Files choices rather than opening the camera directly.

## Gallery image path fix

Gallery asset URLs now decode URL-encoded folder and file names safely before reading the PC filesystem. Images inside folders such as `Raksha Bandhan`, and filenames such as `S25 Ultra Fresh Stock.png`, now load correctly in both the public Gallery and Master Panel.

## Gallery root view

The Gallery’s **All Pictures** item now shows only images stored directly in the root `gallery` directory. Images inside subfolders are intentionally excluded from that view and appear only after selecting their specific folder. Folder counts continue to show the number of images inside each subfolder.

## Project organization

The project is now organized as:

```text
frontend/
  index.html
  public/        # logo, logos, offers, robots, and other browser assets
  src/           # React pages and components
backend/
  server.mjs     # production server and API entry point
  master-gallery.mjs
  inquiry-store.mjs
  offer-assets.mjs
master/          # existing credentials file, preserved separately
gallery/         # existing uploaded gallery folders and images
inquiries/       # existing inquiry workbook data
docs/            # generated production frontend build
```

## Offer image discovery

The Raksha Bandhan page now scans the existing `frontend/public/offers` folder through `/api/offers` and displays every supported PNG, JPG, JPEG, GIF, WEBP, or SVG image it finds. The page no longer depends on a single hardcoded PNG filename. Existing offer images are preserved during update packaging.

Run the reorganized project from its root folder:

```powershell
npm install
npm run build
npm start
```
