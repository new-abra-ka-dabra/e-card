import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import path from "path";
import { fileURLToPath } from "url";
import { saveInquiry } from "./backend/inquiry-store.mjs";
import { createMasterGallery } from "./backend/master-gallery.mjs";
import { scanOfferImages } from "./backend/offer-assets.mjs";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const masterGallery = createMasterGallery({ rootDir: __dirname });

function inquiriesPlugin() {
  return {
    name: "local-inquiries",
    configureServer(server) {
      server.middlewares.use(async (req, res, next) => {
        if (req.method === "GET" && req.url === "/api/offers") {
          res.statusCode = 200;
          res.setHeader("Content-Type", "application/json; charset=utf-8");
          res.end(JSON.stringify({ ok: true, images: scanOfferImages(__dirname) }));
          return;
        }
        if (await masterGallery.handle(req, res)) return;
        next();
      });
      server.middlewares.use("/api/inquiries", (req, res, next) => {
        if (req.method !== "POST") {
          next();
          return;
        }

        let body = "";
        req.on("data", (chunk) => {
          body += chunk;
          if (body.length > 100_000) req.destroy();
        });
        req.on("end", () => {
          try {
            const data = JSON.parse(body || "{}");
            const required = ["name", "company", "phone", "email", "brandsInterested", "message"];
            if (required.some((field) => !String(data[field] || "").trim())) {
              res.statusCode = 400;
              res.setHeader("Content-Type", "application/json");
              res.end(JSON.stringify({ ok: false, message: "All inquiry fields are required." }));
              return;
            }
            const saved = saveInquiry(data);
            res.statusCode = 201;
            res.setHeader("Content-Type", "application/json");
            res.end(JSON.stringify({ ok: true, date: saved.date, time: saved.time }));
          } catch (error) {
            console.error("[inquiries]", error);
            res.statusCode = 500;
            res.setHeader("Content-Type", "application/json");
            res.end(JSON.stringify({ ok: false, message: "Inquiry could not be saved." }));
          }
        });
      });
    },
  };
}

export default defineConfig({
  root: path.resolve(__dirname, "frontend"),
  base: process.env.VITE_BASE_PATH || "/",
  plugins: [inquiriesPlugin(), react(), tailwindcss()],
  resolve: { alias: { "@": path.resolve(__dirname, "frontend/src") } },
  build: {
    outDir: path.resolve(__dirname, "docs"),
    emptyOutDir: true,
    sourcemap: false,
    target: "es2020",
    cssMinify: "lightningcss",
    rollupOptions: {
      output: {
        manualChunks: {
          forms: ["react-hook-form", "@hookform/resolvers", "zod"],
        },
      },
    },
  },
  server: { port: 5000, host: "0.0.0.0", allowedHosts: true },
});
