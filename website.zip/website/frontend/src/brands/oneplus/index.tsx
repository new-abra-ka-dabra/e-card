import BrandCollectionPage from "./BrandCollectionPage";
import logo from "./logo.svg";

export default function OnePlusBrandPage() {
  return <BrandCollectionPage slug="oneplus" name="OnePlus" color="#F50514" logo={logo} />;
}
