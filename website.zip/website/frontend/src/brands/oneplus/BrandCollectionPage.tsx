import { CSSProperties } from "react";
import { ArrowLeft, Construction, MessageCircle, Phone, Sparkles } from "lucide-react";
import { useLocation } from "wouter";
import BrandLogo from "@/components/BrandLogo";

type Props = { slug: string; name: string; color: string; logo: string };

export default function BrandCollectionPage({ slug, name, color, logo }: Props) {
  const [, setLocation] = useLocation();
  return (
    <main className={`brand-page brand-page--${slug} min-h-[calc(100vh-7rem)] px-4 py-12 text-foreground sm:py-20`} style={{ "--brand-accent": color } as CSSProperties}>
      <div className="mx-auto flex max-w-3xl flex-col items-center text-center">
        <button type="button" onClick={() => setLocation("/home")} className="mb-12 inline-flex items-center gap-2 rounded-full border border-[hsl(45_75%_50%/0.28)] bg-card px-4 py-2 text-sm text-muted-foreground transition hover:border-[hsl(45_75%_50%/0.62)] hover:text-foreground"><ArrowLeft className="h-4 w-4" /> Back to Home</button>
        <div className="brand-page__logo gold-border-glow flex min-h-28 min-w-52 items-center justify-center rounded-3xl bg-card px-8 py-6"><BrandLogo name={name} color={color} size={48} logo={logo} /></div>
        <p className="mt-10 inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.25em] text-[hsl(45_75%_50%)]"><Sparkles className="h-4 w-4" /> Brand Collection</p>
        <h1 className="mt-4 font-serif text-4xl font-bold sm:text-6xl">{name}</h1>
        <section className="brand-page__construction mt-8 w-full rounded-3xl border border-amber-300/25 bg-card p-7 sm:p-10">
          <div className="mx-auto grid h-16 w-16 place-items-center rounded-2xl border border-amber-300/30 bg-amber-300/10 text-amber-300"><Construction className="h-8 w-8" /></div>
          <h2 className="mt-6 font-serif text-2xl font-semibold text-amber-100">This collection is under development</h2>
          <p className="mx-auto mt-3 max-w-xl text-sm leading-relaxed text-muted-foreground">We are carefully preparing the latest {name} devices and accessories for this page. Please check back soon or contact our team for current availability and pricing.</p>
          <div className="brand-page__actions mt-7">
            <button type="button" onClick={() => setLocation("/contact")} className="home-hero__primary"><MessageCircle className="h-4 w-4" /> Ask about {name}</button>
            <a href={`https://wa.me/919892139878?text=Hi%2C%20do%20you%20have%20${encodeURIComponent(name)}%20available%3F`} target="_blank" rel="noopener noreferrer" className="home-hero__secondary"><MessageCircle className="h-4 w-4" /> WhatsApp</a>
            <a href="tel:+919892139878" className="home-hero__secondary"><Phone className="h-4 w-4" /> Call store</a>
          </div>
          <div className="brand-page__next-step"><strong>Looking for accessories?</strong><span>We can help with cases, chargers, audio, power and screen protection while this collection is being prepared.</span><button type="button" onClick={() => setLocation("/home")}>Browse all brands <Sparkles className="h-3.5 w-3.5" /></button></div>
        </section>
      </div>
    </main>
  );
}
