import logo from "./logo.svg";
import BrandCollectionPage from "./BrandCollectionPage";
import { SiBoat } from "react-icons/si";

export default function BoatBrandPage() {
  return <BrandCollectionPage slug="boat" name="Boat" color="#E63946" logo={logo} />;
}
