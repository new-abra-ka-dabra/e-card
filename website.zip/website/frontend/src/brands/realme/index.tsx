import logo from "./logo.svg";
import BrandCollectionPage from "./BrandCollectionPage";

export default function RealmeBrandPage() {
  return <BrandCollectionPage slug="realme" name="Realme" color="#e8e8e8" logo={logo} />;
}
