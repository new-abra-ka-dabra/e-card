import logo from "./logo.svg";
import BrandCollectionPage from "./BrandCollectionPage";
import { SiVivo } from "react-icons/si";

export default function VivoBrandPage() {
  return <BrandCollectionPage slug="vivo" name="Vivo" color="#415FFF" logo={logo} />;
}
