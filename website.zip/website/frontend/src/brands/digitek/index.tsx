import logo from "./logo.svg";
import BrandCollectionPage from "./BrandCollectionPage";

export default function DigitekBrandPage() {
  return <BrandCollectionPage slug="digitek" name="Digitek" color="#2980b9" logo={logo} />;
}
