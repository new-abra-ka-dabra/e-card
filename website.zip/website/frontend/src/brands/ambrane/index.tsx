import logo from "./logo.svg";
import BrandCollectionPage from "./BrandCollectionPage";

export default function AmbraneBrandPage() {
  return <BrandCollectionPage slug="ambrane" name="Ambrane" color="#7B2FBE" logo={logo} />;
}
