import logo from "./logo.svg";
import BrandCollectionPage from "./BrandCollectionPage";

export default function MembraneBrandPage() {
  return <BrandCollectionPage slug="membrane" name="Membrane" color="#38BDF8" logo={logo} />;
}
