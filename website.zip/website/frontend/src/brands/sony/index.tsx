import logo from "./logo.svg";
import BrandCollectionPage from "./BrandCollectionPage";
import { SiSony } from "react-icons/si";

export default function SonyBrandPage() {
  return <BrandCollectionPage slug="sony" name="Sony" color="#cccccc" logo={logo} />;
}
