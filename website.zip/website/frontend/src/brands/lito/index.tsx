import logo from "./logo.svg";
import BrandCollectionPage from "./BrandCollectionPage";

export default function LitoBrandPage() {
  return <BrandCollectionPage slug="lito" name="Lito" color="#4ADE80" logo={logo} />;
}
