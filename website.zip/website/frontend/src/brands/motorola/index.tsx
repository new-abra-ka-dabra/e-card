import logo from "./logo.svg";
import BrandCollectionPage from "./BrandCollectionPage";
import { SiMotorola } from "react-icons/si";

export default function MotorolaBrandPage() {
  return <BrandCollectionPage slug="motorola" name="Motorola" color="#5DADE2" logo={logo} />;
}
