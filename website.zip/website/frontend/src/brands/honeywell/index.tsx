import logo from "./logo.svg";
import BrandCollectionPage from "./BrandCollectionPage";

export default function HoneywellBrandPage() {
  return <BrandCollectionPage slug="honeywell" name="Honeywell" color="#e84118" logo={logo} />;
}
