import ApplePage from "./ApplePage";

export default function AppleBrandPage() {
  return <ApplePage />;
}
