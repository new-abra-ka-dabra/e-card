import { useEffect } from "react";
import { ArrowLeft, ArrowRight, Check, ChevronRight, Clock3, CreditCard, Headphones, PackageCheck, RefreshCw, ShieldCheck, Smartphone, Sparkles, Watch } from "lucide-react";
import { useLocation } from "wouter";
import appleLogo from "./logo.svg";
import storefrontImage from "./storefront.jpg";
import iphone17ProImage from "./products/iphone-17-pro.jpg";
import iphoneAirImage from "./products/iphone-air.jpg";
import iphone17Image from "./products/iphone-17.jpg";
import iphone17eImage from "./products/iphone-17e.jpg";
import iphone16Image from "./products/iphone-16.jpg";
import macbookAirImage from "./products/macbook-air.png";
import ipadAirImage from "./products/ipad-air.png";
import appleWatchImage from "./products/apple-watch.jpg";
import airpodsProImage from "./products/airpods-pro.jpg";

type Product = { name: string; eyebrow: string; description: string; image: string; alt: string };

const products: Product[] = [
  { name: "iPhone 17 Pro", eyebrow: "Pro performance", description: "Innovative design, advanced cameras and powerful Apple silicon for demanding days.", image: iphone17ProImage, alt: "iPhone 17 Pro in Cosmic Orange" },
  { name: "iPhone Air", eyebrow: "Thin. Fast. Powerful.", description: "The thinnest iPhone ever, with the power of pro inside and a beautifully light design.", image: iphoneAirImage, alt: "iPhone Air in Sky Blue" },
  { name: "iPhone 17", eyebrow: "Everyday brilliance", description: "Even more delightful and durable, with an advanced camera system for daily life.", image: iphone17Image, alt: "iPhone 17 in Lavender" },
  { name: "iPhone 17e", eyebrow: "Feature stacked", description: "A value-packed iPhone with the essentials people love, in a focused and elegant design.", image: iphone17eImage, alt: "iPhone 17e in Soft Pink" },
  { name: "iPhone 16", eyebrow: "Still a favourite", description: "Amazing performance, durable design and a flexible camera system for photos and video.", image: iphone16Image, alt: "iPhone 16 in Ultramarine" },
  { name: "MacBook Air", eyebrow: "Work. Create. Anywhere.", description: "Thin, portable and built for long days of productivity, study and creativity.", image: macbookAirImage, alt: "MacBook Air product lineup" },
  { name: "MacBook Pro", eyebrow: "For pro workflows", description: "Serious performance and a brilliant display for coding, editing and design.", image: macbookAirImage, alt: "MacBook Pro and MacBook Air product scene" },
  { name: "iPad Air", eyebrow: "Power in a thin design", description: "A flexible canvas for notes, entertainment, creativity and getting things done.", image: ipadAirImage, alt: "iPad Air product scene" },
  { name: "Apple Watch", eyebrow: "Health. Fitness. Connected.", description: "Stay active, connected and informed with a watch that works naturally with iPhone.", image: appleWatchImage, alt: "Apple Watch Series 11 product scene" },
  { name: "AirPods Pro", eyebrow: "Immersive sound", description: "Personal listening with intelligent noise control and seamless Apple pairing.", image: airpodsProImage, alt: "AirPods Pro with iPhone" },
];

const features = [
  { title: "Performance that keeps up", text: "Apple silicon and tightly integrated hardware and software make everyday tasks feel fast, fluid and dependable.", icon: Sparkles },
  { title: "Cameras made simple", text: "Capture sharp photos and steady video with camera systems designed to do more of the work for you.", icon: Smartphone },
  { title: "A battery for the day", text: "Efficient chips, thoughtful software and fast charging help you stay productive, entertained and connected.", icon: Clock3 },
  { title: "Built around privacy", text: "Apple designs privacy into the experience, with useful controls and on-device intelligence where possible.", icon: ShieldCheck },
  { title: "One connected ecosystem", text: "iPhone, Mac, iPad, Apple Watch and AirPods work together through AirDrop, Handoff and iCloud.", icon: RefreshCw },
  { title: "Made to feel personal", text: "Choose the product, finish, storage and accessories that match the way you work, create and live.", icon: Check },
];

const buyingOptions = [
  { title: "Trade-in guidance", text: "Bring your current smartphone and our team can help you understand trade-in options and upgrade paths.", icon: RefreshCw },
  { title: "Flexible ways to pay", text: "Ask about eligible card offers, EMI options and current store promotions before you buy.", icon: CreditCard },
  { title: "Personal setup", text: "We can help with data transfer, account setup, accessories and the first steps with your new device.", icon: ShieldCheck },
  { title: "Pickup or delivery", text: "Confirm local availability, reserve your choice and arrange the most convenient way to receive it.", icon: PackageCheck },
];

function ProductArt({ image, alt }: Pick<Product, "image" | "alt">) {
  return <div className="apple-product-art"><img className="apple-product-art__image" src={image} alt={alt} loading="lazy" /></div>;
}

export default function ApplePage() {
  const [, setLocation] = useLocation();
  useEffect(() => {
    window.scrollTo({ top: 0, left: 0, behavior: "auto" });
    document.documentElement.scrollTop = 0;
    document.body.scrollTop = 0;
  }, []);
  return (
    <main className="apple-page min-h-screen bg-[#070707] text-[#f5f5f7]">
      <section className="apple-page__hero">
        <div className="apple-page__hero-copy">
          <button type="button" onClick={() => setLocation("/home")} className="apple-page__back"><ArrowLeft className="h-4 w-4" /> Back to Home</button>
          <div className="apple-page__brand-lockup"><img src={appleLogo} alt="Apple logo" /><span>Apple collection</span></div>
          <p className="apple-page__eyebrow">Explore the Apple lineup</p>
          <h1>Powerful ideas.<br /><em>Beautifully connected.</em></h1>
          <p className="apple-page__hero-text">Discover iPhone, Mac, iPad, Apple Watch and AirPods in one considered collection. Visit our Powai store for current availability, colours, storage options and advice from a real person.</p>
        </div>
        <div className="apple-page__hero-visual"><img src={storefrontImage} alt="Apple products and devices on display" /><div className="apple-page__hero-visual-caption"><span>In-store experience</span><strong>See the ecosystem<br />come together.</strong></div></div>
      </section>

      <section className="apple-page__intro"><p className="apple-page__eyebrow">Apple, your way</p><h2>Explore the Apple lineup.</h2><p>Start with the product that fits your world. We’ll help you compare models, choose the right configuration and build a setup that feels effortless.</p></section>

      <section className="apple-page__product-grid" aria-label="Apple products">
        {products.map((product) => <article key={product.name} id={product.name.toLowerCase().replace(/[^a-z]+/g, "-")} className="apple-product-card"><ProductArt image={product.image} alt={product.alt} /><div className="apple-product-card__copy"><p className="apple-product-card__eyebrow">{product.eyebrow}</p><h3>{product.name}</h3><p>{product.description}</p><button type="button" onClick={() => setLocation("/contact")} className="apple-text-link">Check availability <ChevronRight className="h-4 w-4" /></button></div></article>)}
      </section>

      <section id="support" className="apple-page__support"><div className="apple-page__section-heading"><p className="apple-page__eyebrow">More than a purchase</p><h2>Make your next Apple choice with confidence.</h2><p>Like the best specialist retail experiences, the right details sit close to the product: trade-in guidance, payment options, setup and support.</p></div><div className="apple-support-grid">{buyingOptions.map(({ title, text, icon: Icon }) => <article key={title} className="apple-support-card"><Icon className="h-5 w-5" /><h3>{title}</h3><p>{text}</p><button type="button" onClick={() => setLocation("/contact")} className="apple-text-link">Check availability <ArrowRight className="h-4 w-4" /></button></article>)}</div></section>

      <section className="apple-feature-grid">{features.map(({ title, text, icon: Icon }) => <article key={title} className="apple-feature-card"><div className="apple-feature-card__icon"><Icon className="h-5 w-5" /></div><h3>{title}</h3><p>{text}</p></article>)}</section>

      <section id="airpods-pro" className="apple-page__accessories"><div className="apple-page__section-heading"><p className="apple-page__eyebrow">Finish the experience</p><h2>Apple essentials.</h2><p>Protect, power and personalise your devices with accessories chosen for everyday use.</p></div><div className="apple-accessory-row"><div><Smartphone /><span>Cases & protection</span></div><div><CreditCard /><span>Chargers & cables</span></div><div><Headphones /><span>AirPods & audio</span></div><div><Watch /><span>Bands & power</span></div></div></section>

    </main>
  );
}

