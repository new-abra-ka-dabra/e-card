import logo from "./logo.svg";
import BrandCollectionPage from "./BrandCollectionPage";

export default function PortronicsBrandPage() {
  return <BrandCollectionPage slug="portronics" name="Portronics" color="#00C4CC" logo={logo} />;
}
