import type { ComponentType, CSSProperties } from "react";
import { SiApple, SiXiaomi, SiMotorola, SiNokia, SiSony, SiVivo, SiGoogle, SiBoat } from "react-icons/si";
import appleLogo from "./apple/logo.svg";
import samsungLogo from "./samsung/logo.svg";
import xiaomiLogo from "./xiaomi/logo.svg";
import googleLogo from "./google/logo.svg";
import motorolaLogo from "./motorola/logo.svg";
import vivoLogo from "./vivo/logo.svg";
import oneplusLogo from "./oneplus/logo.svg";
import sonyLogo from "./sony/logo.svg";
import realmeLogo from "./realme/logo.svg";
import nokiaLogo from "./nokia/logo.svg";
import itelLogo from "./itel/logo.svg";
import stuffcoolLogo from "./stuffcool/logo.svg";
import portronicsLogo from "./portronics/logo.svg";
import boatLogo from "./boat/logo.svg";
import boseLogo from "./bose/logo.svg";
import ambraneLogo from "./ambrane/logo.svg";
import honeywellLogo from "./honeywell/logo.svg";
import digitekLogo from "./digitek/logo.svg";

export type BrandCard = {
  name: string;
  slug: string;
  logo: string;
  icon?: ComponentType<{ style?: CSSProperties }>;
  color: string;
  status: string;
};

export const mobileBrands: BrandCard[] = [
  { name: "Apple", slug: "apple", logo: appleLogo, icon: SiApple, color: "#e0e0e0", status: "Available on request" },
  { name: "Samsung", slug: "samsung", logo: samsungLogo, color: "#ffffff", status: "Available on request" },
  { name: "Xiaomi", slug: "xiaomi", logo: xiaomiLogo, icon: SiXiaomi, color: "#FF6900", status: "Available on request" },
  { name: "Google", slug: "google", logo: googleLogo, icon: SiGoogle, color: "#4285F4", status: "Coming soon" },
  { name: "Motorola", slug: "motorola", logo: motorolaLogo, icon: SiMotorola, color: "#5DADE2", status: "Coming soon" },
  { name: "Vivo", slug: "vivo", logo: vivoLogo, icon: SiVivo, color: "#415FFF", status: "Coming soon" },
  { name: "OnePlus", slug: "oneplus", logo: oneplusLogo, color: "#F50514", status: "Coming soon" },
  { name: "Realme", slug: "realme", logo: realmeLogo, color: "#e8e8e8", status: "Coming soon" },
  { name: "Nokia", slug: "nokia", logo: nokiaLogo, icon: SiNokia, color: "#5DADE2", status: "Coming soon" },
  { name: "Itel", slug: "itel", logo: itelLogo, color: "#00BFFF", status: "Coming soon" },
];

export const accessoryBrands: BrandCard[] = [
  { name: "Sony", slug: "sony", logo: sonyLogo, icon: SiSony, color: "#cccccc", status: "Coming soon" },
  { name: "Stuffcool", slug: "stuffcool", logo: stuffcoolLogo, color: "#FF6B35", status: "Coming soon" },
  { name: "Portronics", slug: "portronics", logo: portronicsLogo, color: "#00C4CC", status: "Coming soon" },
  { name: "Boat", slug: "boat", logo: boatLogo, icon: SiBoat, color: "#E63946", status: "Coming soon" },
  { name: "Bose", slug: "bose", logo: boseLogo, color: "#d4af37", status: "Coming soon" },
  { name: "Ambrane", slug: "ambrane", logo: ambraneLogo, color: "#7B2FBE", status: "Coming soon" },
  { name: "Honeywell", slug: "honeywell", logo: honeywellLogo, color: "#e84118", status: "Coming soon" },
  { name: "Digitek", slug: "digitek", logo: digitekLogo, color: "#2980b9", status: "Coming soon" },
];
