import logo from "./logo.svg";
import BrandCollectionPage from "./BrandCollectionPage";

export default function NeopackBrandPage() {
  return <BrandCollectionPage slug="neopack" name="Neopack" color="#FB923C" logo={logo} />;
}
