import logo from "./logo.svg";
import BrandCollectionPage from "./BrandCollectionPage";

export default function ItelBrandPage() {
  return <BrandCollectionPage slug="itel" name="Itel" color="#00BFFF" logo={logo} />;
}
