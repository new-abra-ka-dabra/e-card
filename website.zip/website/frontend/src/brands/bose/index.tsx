import logo from "./logo.svg";
import BrandCollectionPage from "./BrandCollectionPage";

export default function BoseBrandPage() {
  return <BrandCollectionPage slug="bose" name="Bose" color="#d4af37" logo={logo} />;
}
