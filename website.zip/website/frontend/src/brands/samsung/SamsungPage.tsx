import { useEffect } from "react";
import { ArrowLeft, ArrowRight, Check, ChevronRight, CreditCard, Headphones, PackageCheck, RefreshCw, ShieldCheck, Smartphone, Sparkles, Watch } from "lucide-react";
import { useLocation } from "wouter";
import samsungLogo from "./logo.svg";
import samsungHeroImage from "./products/galaxy-devices.jpg";
import galaxyZLineupImage from "./products/galaxy-z-lineup.jpg";
import galaxyZFoldImage from "./products/galaxy-z-fold.jpg";
import galaxyWatchBudsImage from "./products/galaxy-watch-buds.jpg";
import galaxyDevicesImage from "./products/galaxy-devices.jpg";

type Product = { name: string; eyebrow: string; description: string; image: string; alt: string };

const products: Product[] = [
  { name: "Galaxy S26 Ultra", eyebrow: "Ultra power", description: "A flagship Galaxy experience built around advanced cameras, a vivid display and performance for demanding days.", image: galaxyDevicesImage, alt: "Samsung Galaxy flagship device lineup" },
  { name: "Galaxy S26", eyebrow: "Everyday flagship", description: "A refined Galaxy S experience with thoughtful design, powerful performance and an effortless everyday camera.", image: galaxyDevicesImage, alt: "Samsung Galaxy S flagship devices" },
  { name: "Galaxy Z Fold8 Ultra", eyebrow: "Unfold your next idea", description: "A large-screen foldable experience designed for multitasking, creative work and immersive entertainment.", image: galaxyZFoldImage, alt: "Samsung Galaxy Z Fold foldable phone" },
  { name: "Galaxy Z Fold8", eyebrow: "Open up more", description: "Move between a compact cover screen and a spacious inner display for work, play and everything between.", image: galaxyZLineupImage, alt: "Samsung Galaxy Z Fold and Flip lineup" },
  { name: "Galaxy Z Flip8", eyebrow: "Pocket-sized personality", description: "A compact foldable with a flexible form factor that makes quick moments and self-expression feel natural.", image: galaxyZLineupImage, alt: "Samsung Galaxy Z Flip foldable phones" },
  { name: "Galaxy A series", eyebrow: "Made for more", description: "Reliable Galaxy essentials with bright screens, capable cameras and the features that matter every day.", image: galaxyDevicesImage, alt: "Samsung Galaxy smartphone collection" },
  { name: "Galaxy Tab", eyebrow: "Peak productivity", description: "A versatile canvas for notes, streaming, creativity and focused work with S Pen and Galaxy AI experiences.", image: galaxyDevicesImage, alt: "Samsung Galaxy Tab tablet in a Samsung device lineup" },
  { name: "Galaxy Watch", eyebrow: "Health, at a glance", description: "Seamless health tracking, fitness insights and connected notifications in a watch designed to keep up.", image: galaxyWatchBudsImage, alt: "Samsung Galaxy Watch with Galaxy Buds" },
  { name: "Galaxy Buds", eyebrow: "Immersive audio", description: "Comfortable listening with intelligent sound, clear calls and a connected Galaxy audio experience.", image: galaxyWatchBudsImage, alt: "Samsung Galaxy Buds wireless earbuds" },
];

const features = [
  { title: "Galaxy AI, made useful", text: "Explore helpful AI experiences across search, communication, creativity and everyday productivity.", icon: Sparkles },
  { title: "Cameras for real life", text: "Capture people, places and night scenes with camera tools designed to make great moments easier to keep.", icon: Smartphone },
  { title: "Screens that invite you in", text: "Enjoy vivid displays for films, games, reading and creative work across phones, tablets and foldables.", icon: Check },
  { title: "Connected by Galaxy", text: "Move naturally between Galaxy phone, tablet, watch, Buds and other devices through a connected experience.", icon: RefreshCw },
  { title: "Built for your routine", text: "Choose a compact phone, an Ultra flagship, a foldable, a tablet or a wearable around the way you live.", icon: Watch },
  { title: "Ready for the next thing", text: "Flexible designs, useful accessories and dependable performance help your setup stay ready for change.", icon: ShieldCheck },
];

const buyingOptions = [
  { title: "Compare Galaxy models", text: "We can help you compare screen sizes, cameras, storage, performance and form factors before you choose.", icon: Smartphone },
  { title: "Flexible ways to pay", text: "Ask about eligible card offers, EMI options and current store promotions before you buy.", icon: CreditCard },
  { title: "Personal setup", text: "Get help with data transfer, Samsung account setup, accessories and the first steps with your new Galaxy device.", icon: ShieldCheck },
  { title: "Pickup or delivery", text: "Confirm current availability, reserve your choice and arrange the most convenient way to receive it.", icon: PackageCheck },
];

function ProductArt({ image, alt }: Pick<Product, "image" | "alt">) {
  return <div className="apple-product-art samsung-product-art"><img className="apple-product-art__image" src={image} alt={alt} loading="lazy" /></div>;
}

export default function SamsungPage() {
  const [, setLocation] = useLocation();
  useEffect(() => {
    window.scrollTo({ top: 0, left: 0, behavior: "auto" });
    document.documentElement.scrollTop = 0;
    document.body.scrollTop = 0;
  }, []);

  return (
    <main className="apple-page samsung-page min-h-screen bg-[#070707] text-[#f5f5f7]">
      <section className="apple-page__hero samsung-page__hero">
        <div className="apple-page__hero-copy samsung-page__hero-copy">
          <button type="button" onClick={() => setLocation("/home")} className="apple-page__back"><ArrowLeft className="h-4 w-4" /> Back to Home</button>
          <div className="apple-page__brand-lockup samsung-page__brand-lockup"><img src={samsungLogo} alt="Samsung logo" /><span>Samsung collection</span></div>
          <p className="apple-page__eyebrow samsung-page__eyebrow">Explore the Galaxy lineup</p>
          <h1>Galaxy for<br /><em>every way of living.</em></h1>
          <p className="apple-page__hero-text">Discover Galaxy smartphones, foldables, tablets, watches and Buds in one connected collection. Explore the form factor, camera and experience that feels right for you.</p>
        </div>
        <div className="apple-page__hero-visual samsung-page__hero-visual"><img src={samsungHeroImage} alt="Samsung Galaxy devices across phone, tablet and wearable categories" /><div className="apple-page__hero-visual-caption"><span>Galaxy ecosystem</span><strong>More ways to<br />make it yours.</strong></div></div>
      </section>

      <section className="apple-page__intro samsung-page__intro"><p className="apple-page__eyebrow samsung-page__eyebrow">Galaxy, your way</p><h2>Explore the Samsung lineup.</h2><p>Start with the Galaxy experience that fits your world. We’ll help you compare models, choose the right configuration and build a setup that feels effortless.</p></section>

      <section className="apple-page__product-grid samsung-page__product-grid" aria-label="Samsung Galaxy products">
        {products.map((product) => <article key={product.name} className="apple-product-card samsung-product-card"><ProductArt image={product.image} alt={product.alt} /><div className="apple-product-card__copy"><p className="apple-product-card__eyebrow samsung-page__eyebrow">{product.eyebrow}</p><h3>{product.name}</h3><p>{product.description}</p><button type="button" onClick={() => setLocation("/contact")} className="apple-text-link samsung-page__link">Check availability <ChevronRight className="h-4 w-4" /></button></div></article>)}
      </section>

      <section className="apple-page__support samsung-page__support"><div className="apple-page__section-heading"><p className="apple-page__eyebrow samsung-page__eyebrow">More than a purchase</p><h2>Make your next Galaxy choice with confidence.</h2><p>Find the right screen, camera, form factor and connected accessories with clear, practical guidance from our team.</p></div><div className="apple-support-grid">{buyingOptions.map(({ title, text, icon: Icon }) => <article key={title} className="apple-support-card"><Icon className="h-5 w-5" /><h3>{title}</h3><p>{text}</p><button type="button" onClick={() => setLocation("/contact")} className="apple-text-link samsung-page__link">Check availability <ArrowRight className="h-4 w-4" /></button></article>)}</div></section>

      <section className="apple-feature-grid samsung-page__feature-grid">{features.map(({ title, text, icon: Icon }) => <article key={title} className="apple-feature-card"><div className="apple-feature-card__icon"><Icon className="h-5 w-5" /></div><h3>{title}</h3><p>{text}</p></article>)}</section>

      <section className="apple-page__accessories samsung-page__accessories"><div className="apple-page__section-heading"><p className="apple-page__eyebrow samsung-page__eyebrow">Complete your setup</p><h2>Galaxy essentials.</h2><p>Protect, power and personalise your devices with accessories chosen for everyday use.</p></div><div className="apple-accessory-row"><div><Smartphone /><span>Cases & protection</span></div><div><CreditCard /><span>Chargers & cables</span></div><div><Headphones /><span>Galaxy Buds & audio</span></div><div><Watch /><span>Watch bands & power</span></div></div></section>
    </main>
  );
}
