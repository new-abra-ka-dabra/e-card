import SamsungPage from "./SamsungPage";

export default function SamsungBrandPage() {
  return <SamsungPage />;
}
