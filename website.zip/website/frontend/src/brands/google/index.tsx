import logo from "./logo.svg";
import BrandCollectionPage from "./BrandCollectionPage";
import { SiGoogle } from "react-icons/si";

export default function GoogleBrandPage() {
  return <BrandCollectionPage slug="google" name="Google" color="#4285F4" logo={logo} />;
}
