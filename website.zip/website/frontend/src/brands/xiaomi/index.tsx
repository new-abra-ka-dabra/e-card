import logo from "./logo.svg";
import BrandCollectionPage from "./BrandCollectionPage";
import { SiXiaomi } from "react-icons/si";

export default function XiaomiBrandPage() {
  return <BrandCollectionPage slug="xiaomi" name="Xiaomi" color="#FF6900" logo={logo} />;
}
