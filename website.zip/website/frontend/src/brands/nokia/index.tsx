import logo from "./logo.svg";
import BrandCollectionPage from "./BrandCollectionPage";
import { SiNokia } from "react-icons/si";

export default function NokiaBrandPage() {
  return <BrandCollectionPage slug="nokia" name="Nokia" color="#5DADE2" logo={logo} />;
}
