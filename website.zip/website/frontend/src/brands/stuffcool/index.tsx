import logo from "./logo.svg";
import BrandCollectionPage from "./BrandCollectionPage";

export default function StuffcoolBrandPage() {
  return <BrandCollectionPage slug="stuffcool" name="Stuffcool" color="#FF6B35" logo={logo} />;
}
