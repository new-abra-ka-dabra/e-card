import logo from "./logo.svg";
import BrandCollectionPage from "./BrandCollectionPage";

export default function SpigenBrandPage() {
  return <BrandCollectionPage slug="spigen" name="Spigen" color="#e0e0e0" logo={logo} />;
}
