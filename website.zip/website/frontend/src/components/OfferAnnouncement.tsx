import { ChevronRight, Sparkles } from "lucide-react";
import { useLocation } from "wouter";

export default function OfferAnnouncement() {
  const [, setLocation] = useLocation();
  return (
    <aside className="offer-announcement" aria-label="Raksha Bandhan offer announcement">
      <div className="offer-announcement__icon" aria-hidden="true"><Sparkles className="h-4 w-4" /></div>
      <div className="offer-marquee" aria-live="polite">
        <div className="offer-marquee__track"><span>Raksha Bandhan gifts on purchases above ₹15,000</span><span aria-hidden="true">Raksha Bandhan gifts on purchases above ₹15,000</span></div>
      </div>
      <button type="button" className="offer-announcement__action" onClick={() => setLocation("/raksha-bandhan-offers")}>View offer <ChevronRight className="h-3.5 w-3.5" /></button>
    </aside>
  );
}
