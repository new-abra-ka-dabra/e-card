import { useState } from "react";
import { useLocation } from "wouter";
import { X, Menu, Home, Image, Briefcase, Phone } from "lucide-react";

const links = [
  { label: "Home",      path: "/home",        Icon: Home      },
  { label: "B2B Deals", path: "/b2b",     Icon: Briefcase },
  { label: "Gallery",   path: "/gallery", Icon: Image     },
  { label: "Contact",   path: "/contact", Icon: Phone     },
];

export default function Nav() {
  const [open, setOpen] = useState(false);
  const [location, setLocation] = useLocation();

  const navigate = (path: string) => {
    setLocation(path);
    setOpen(false);
  };

  return (
    <>
      <header className="desktop-nav" aria-label="Desktop primary navigation">
        <button type="button" className="desktop-nav__brand" onClick={() => navigate("/home")} aria-label="Go to New Abra Ka Dabra home">
          <span className="desktop-nav__brand-mark"><img src={`${import.meta.env.BASE_URL}logo.png`} alt="New Abra Ka Dabra" /></span>
          <span><strong>New Abra Ka Dabra</strong><small>Mobile &amp; Electronics · Powai</small></span>
        </button>
        <nav className="desktop-nav__links" aria-label="Primary">
          {links.map(({ label, path, Icon }) => {
            const active = location === path;
            return <button key={path} type="button" onClick={() => navigate(path)} className={`desktop-nav__link ${active ? "desktop-nav__link--active" : ""}`} aria-current={active ? "page" : undefined}><Icon className="h-4 w-4" />{label}</button>;
          })}
        </nav>
      </header>

      {/* Mobile top bar */}
      <header className="mobile-topbar" aria-label="Mobile primary navigation">
        <button type="button" className="mobile-topbar__brand" onClick={() => navigate("/home")} aria-label="Go to New Abra Ka Dabra home">
          <span className="mobile-topbar__mark"><img src={`${import.meta.env.BASE_URL}logo.png`} alt="New Abra Ka Dabra" /></span>
          <span className="mobile-topbar__text">
            <span className="mobile-topbar__name">New Abra Ka Dabra</span>
            <span className="mobile-topbar__tagline">Mobile &amp; Electronics · Powai</span>
          </span>
        </button>
        <button
          type="button"
          data-testid="button-menu-toggle"
          onClick={() => setOpen(true)}
          className="mobile-topbar__menu-btn"
          aria-label="Open menu"
        >
          <Menu className="w-5 h-5 text-[hsl(45_75%_62%)]" />
        </button>
      </header>

      {/* Backdrop */}
      {open && (
        <div
          className="mobile-menu-backdrop fixed inset-0 z-40 bg-black/60 backdrop-blur-sm"
          onClick={() => setOpen(false)}
        />
      )}

      {/* Drawer */}
      <div
        className="mobile-menu-drawer fixed top-0 right-0 h-full z-50 flex flex-col"
        style={{
          width: "min(280px, 85vw)",
          background: "hsl(0 0% 8%)",
          borderLeft: "1px solid hsl(45 75% 50% / 0.2)",
          boxShadow: "-8px 0 32px hsl(0 0% 0% / 0.6)",
          transform: open ? "translateX(0)" : "translateX(100%)",
          transition: "transform 0.3s cubic-bezier(.4,0,.2,1)",
        }}
      >
        {/* Drawer header */}
        <div
          className="flex items-center justify-between px-6 py-5 border-b"
          style={{ borderColor: "hsl(45 75% 50% / 0.15)" }}
        >
          <div>
            <p className="text-[12px] tracking-[0.3em] uppercase text-[hsl(45_75%_50%)]">Menu</p>
            <p className="text-base font-serif font-bold gold-text mt-0.5">New Abra Ka Dabra</p>
          </div>
          <button
            data-testid="button-menu-close"
            onClick={() => setOpen(false)}
            className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-white/5 transition-colors"
          >
            <X className="w-4 h-4 text-muted-foreground" />
          </button>
        </div>

        {/* Nav links */}
        <nav className="flex-1 px-4 py-6 flex flex-col gap-1">
          {links.map(({ label, path, Icon }) => {
            const active = location === path;
            return (
              <button
                key={path}
                data-testid={`nav-link-${label.toLowerCase().replace(/\s+/g, "-")}`}
                onClick={() => navigate(path)}
                className="flex items-center gap-3 px-4 py-3.5 rounded-xl text-left transition-all"
                style={{
                  background: active ? "hsl(45 75% 50% / 0.12)" : "transparent",
                  borderLeft: active ? "2px solid hsl(45 75% 50%)" : "2px solid transparent",
                }}
              >
                <Icon
                  className="w-4 h-4 flex-shrink-0"
                  style={{ color: active ? "hsl(45 75% 62%)" : "hsl(45 20% 50%)" }}
                />
                <span
                  className="text-sm font-medium"
                  style={{ color: active ? "hsl(45 75% 80%)" : "hsl(45 20% 65%)" }}
                >
                  {label}
                </span>
              </button>
            );
          })}
        </nav>

        {/* Drawer footer */}
        <div
          className="px-6 py-5 border-t"
          style={{ borderColor: "hsl(45 75% 50% / 0.15)" }}
        >
          <p className="text-[12px] text-muted-foreground">
            Shop No. 70, Galleria Mall, Powai
          </p>
          <p className="text-[12px] text-muted-foreground mt-0.5">Open 10AM – 10PM · All Days</p>
        </div>
      </div>
    </>
  );
}
