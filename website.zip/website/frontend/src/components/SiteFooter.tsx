import { Heart, Instagram, MessageCircle } from "lucide-react";
import { useLocation } from "wouter";

export default function SiteFooter() {
  const [, setLocation] = useLocation();

  return (
    <>
      <footer className="site-footer site-footer--structured">
        <div className="site-footer__upper">
          <div className="site-footer__brand site-footer__brand--large">
            <img src={`${import.meta.env.BASE_URL}logo.png`} alt="New Abra Ka Dabra logo" />
            <div>
              <strong>New Abra Ka Dabra</strong>
              <span>Mobile &amp; Electronics · Powai</span>
              <em>Your trusted destination for premium mobile &amp; electronics.</em>
            </div>
          </div>

          <div className="site-footer__column site-footer__links-column">
            <p className="site-footer__label">Quick links</p>
            <nav className="site-footer__quick-links" aria-label="Footer navigation">
              <button type="button" onClick={() => setLocation("/home")}>Home</button>
              <button type="button" onClick={() => setLocation("/b2b")}>Deals</button>
              <button type="button" onClick={() => setLocation("/gallery")}>Gallery</button>
              <button type="button" onClick={() => setLocation("/contact")}>Contact</button>
            </nav>
          </div>

          <div className="site-footer__column site-footer__follow">
            <p className="site-footer__label">Follow us</p>
            <a href="https://www.instagram.com/newabrakadabra70" target="_blank" rel="noopener noreferrer" aria-label="Follow New Abra Ka Dabra on Instagram">
              <Instagram className="h-6 w-6" />
            </a>
          </div>

          <div className="site-footer__column site-footer__payments">
            <p className="site-footer__label">We accept</p>
              <div className="site-footer__payment-marks" aria-label="Accepted payment methods">
                <img className="site-footer__payment-logo" src={`${import.meta.env.BASE_URL}payment/mastercard.svg`} alt="Mastercard" />
                <img className="site-footer__payment-logo" src={`${import.meta.env.BASE_URL}payment/visa.svg`} alt="Visa" />
                <img className="site-footer__payment-logo" src={`${import.meta.env.BASE_URL}payment/discover.svg`} alt="Discover" />
                <img className="site-footer__payment-logo" src={`${import.meta.env.BASE_URL}payment/upi.svg`} alt="UPI" />
              </div>
          </div>
        </div>

        <div className="site-footer__lower">
          <span>© 2024 New Abra Ka Dabra. All Rights Reserved.</span>
          <span>Made with <Heart className="site-footer__heart" aria-label="love" /> for our customers.</span>
        </div>
      </footer>
      <a className="whatsapp-float" href="https://wa.me/919892139878?text=Hi%2C%20I%20need%20help%20with%20a%20mobile%20or%20accessory" target="_blank" rel="noopener noreferrer" aria-label="Chat with New Abra Ka Dabra on WhatsApp"><MessageCircle className="h-5 w-5" /><span>WhatsApp</span></a>
    </>
  );
}
