import { useEffect } from "react";
import { useLocation } from "wouter";

type SeoConfig = { title: string; description: string; image?: string; type?: string; robots?: string; jsonLd?: Record<string, unknown> };
const baseUrl = typeof window !== "undefined" ? window.location.origin : "";
const homeSeo: SeoConfig = { title: "Mobile Phones, Tablets & Accessories in Powai | New Abra Ka Dabra", description: "Shop mobile phones, tablets, smartphone accessories, covers, chargers and screen protectors in Powai, Mumbai at New Abra Ka Dabra, Galleria Mall." };
const seoByRoute: Record<string, SeoConfig> = {
  "/": homeSeo, "/home": homeSeo,
  "/b2b": { title: "B2B Mobile Wholesale Deals in Mumbai | New Abra Ka Dabra", description: "Bulk mobile phones, tablets, accessories and screen protectors for retailers, corporates, schools and resellers across Mumbai. Send a B2B enquiry." },
  "/gallery": { title: "Mobile Store Gallery in Powai | New Abra Ka Dabra", description: "See product arrivals and a glimpse inside New Abra Ka Dabra mobile store at Galleria Mall, Powai, Mumbai." },
  "/contact": { title: "Contact Mobile Store in Powai, Mumbai | New Abra Ka Dabra", description: "Contact New Abra Ka Dabra for mobile phones, tablets, accessories, B2B enquiries, directions and store hours in Galleria Mall, Powai." },
  "/master": { title: "Master Gallery Login | New Abra Ka Dabra", description: "Private gallery management panel.", robots: "noindex, nofollow, noarchive" },
  "/raksha-bandhan-offers": { title: "Raksha Bandhan Mobile Offers in Powai | Free Gifts on ₹15,000+", description: "Shop Raksha Bandhan mobile phone and accessories offers at New Abra Ka Dabra, Powai. Get a free watch worth ₹3,000, bag and umbrella on purchases above ₹15,000 from 20 Aug to 29 Aug.", image: `${baseUrl}/offers/raksha-bandhan-offers.jpeg`, type: "article" },
};
function setMeta(attribute: "name" | "property", key: string, content: string) {
  let element = document.head.querySelector<HTMLMetaElement>(`meta[${attribute}="${key}"]`);
  if (!element) { element = document.createElement("meta"); element.setAttribute(attribute, key); document.head.appendChild(element); }
  element.content = content;
}
export default function Seo() {
  const [location] = useLocation();
  const route = location.split("?")[0] || "/home";
  const brandMatch = route.match(/^\/brand\/([^/]+)$/);
  const brandName = brandMatch?.[1] ? brandMatch[1].charAt(0).toUpperCase() + brandMatch[1].slice(1) : "";
  const config = brandName ? { title: `${brandName} Mobile Phones & Accessories | New Abra Ka Dabra`, description: `Explore ${brandName} mobile phones and accessories at New Abra Ka Dabra in Powai, Mumbai. Contact our team for current availability and pricing.` } : (seoByRoute[route] || homeSeo);
  useEffect(() => {
    const canonicalPath = route === "/" ? "/home" : route;
    const canonicalUrl = `${window.location.origin}${canonicalPath}`;
    document.title = config.title;
    setMeta("name", "description", config.description);
    setMeta("name", "robots", config.robots || "index, follow");
    setMeta("property", "og:title", config.title);
    setMeta("property", "og:description", config.description);
    setMeta("property", "og:type", config.type || "website");
    setMeta("property", "og:url", canonicalUrl);
    setMeta("property", "og:image", config.image || `${window.location.origin}/opengraph.jpg`);
    setMeta("name", "twitter:title", config.title);
    setMeta("name", "twitter:description", config.description);
    setMeta("name", "twitter:image", config.image || `${window.location.origin}/opengraph.jpg`);
    let canonical = document.head.querySelector<HTMLLinkElement>('link[rel="canonical"]');
    if (!canonical) { canonical = document.createElement("link"); canonical.rel = "canonical"; document.head.appendChild(canonical); }
    canonical.href = canonicalUrl;
  }, [config, route]);
  return null;
}
