import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { SiInstagram } from "react-icons/si";
import { mobileBrands, accessoryBrands } from "@/brands/catalog";
import { Phone, MapPin, ChevronRight, Smartphone, Zap, Shield, Headphones, Gift, CalendarDays, ArrowUpRight, MessageCircle } from "lucide-react";
import BrandLogo from "@/components/BrandLogo";

const features = [
  { Icon: Smartphone, label: "All Top Brands",   desc: "Every major brand under one roof" },
  { Icon: Zap,        label: "Best Prices",      desc: "Competitive pricing guaranteed"   },
  { Icon: Shield,     label: "Genuine Products", desc: "100% authentic devices always"    },
];

type FeaturedImage = { name: string; url: string; folder: string };

export default function Home() {
  const [, setLocation] = useLocation();
  const [featuredImages, setFeaturedImages] = useState<FeaturedImage[]>([]);
  const [featuredIndex, setFeaturedIndex] = useState(0);

  useEffect(() => {
    let active = true;
    fetch("/api/gallery", { headers: { Accept: "application/json" } })
      .then((response) => response.ok ? response.json() : { images: [] })
      .then((data) => {
        if (!active) return;
        const images = Array.isArray(data.images) ? data.images : [];
        setFeaturedImages(images.filter((image: FeaturedImage) => image.folder === "featured").sort((a: FeaturedImage, b: FeaturedImage) => a.name.localeCompare(b.name)));
      })
      .catch(() => undefined);
    return () => { active = false; };
  }, []);

  useEffect(() => {
    if (featuredImages.length < 2) return;
    const timer = window.setInterval(() => setFeaturedIndex((current) => (current + 1) % featuredImages.length), 4200);
    return () => window.clearInterval(timer);
  }, [featuredImages.length]);

  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">

      {/* ── Magical hero ── */}
      <header className="magic-hero relative overflow-hidden px-4 py-12 sm:px-6 sm:py-16">
        <div className="magic-hero__halo" aria-hidden="true" />
        <div className="magic-hero__wand magic-hero__wand--one" aria-hidden="true" />
        <div className="magic-hero__wand magic-hero__wand--two" aria-hidden="true" />
        <div className="relative z-10 mx-auto grid max-w-6xl items-center gap-10 lg:grid-cols-[1.05fr_.95fr] lg:gap-16">
          <div className="animate-fade-in-up text-center lg:text-left">
            <p className="magic-hero__eyebrow">Your local mobile &amp; electronics studio</p>
            <h1 className="mt-4 max-w-3xl font-serif text-4xl font-bold leading-[1.02] tracking-tight gold-text sm:text-6xl">Find the device that feels meant for you.</h1>
            <p className="mx-auto mt-5 max-w-xl text-sm leading-relaxed text-muted-foreground sm:text-base lg:mx-0">Trusted devices, useful accessories, and thoughtful advice from our store in Powai. Tell us what you need and we’ll help you find the right fit.</p>
            <div className="mt-7 flex flex-col justify-center gap-3 sm:flex-row lg:justify-start">
              <button type="button" onClick={() => setLocation("/contact")} className="home-hero__primary"><MessageCircle className="h-4 w-4" /> Ask our team</button>
              <button type="button" onClick={() => setLocation("/gallery")} className="home-hero__secondary">See our store <ArrowUpRight className="h-4 w-4" /></button>
            </div>
            <div className="magic-hero__spark-row" aria-hidden="true"><span>✦</span><i /><span>✧</span><i /><span>✦</span></div>
          </div>
          <div className="home-hero__visual home-hero__visual--carousel animate-scale-in" aria-label="Featured products and store highlights">
            {featuredImages.length > 0 ? (
              <>
                <div className="home-hero__slides" style={{ transform: `translateX(-${featuredIndex * 100}%)` }}>
                  {featuredImages.map((image, index) => <div className="home-hero__slide" key={image.url}><img src={image.url} alt={`Featured store image ${index + 1}`} /><span className="home-hero__image-name">{image.name.replace(/\.[^/.]+$/, "")}</span></div>)}
                </div>
                {featuredImages.length > 1 && <div className="home-hero__dots" aria-label="Featured image navigation">{featuredImages.map((image, index) => <button type="button" key={image.url} onClick={() => setFeaturedIndex(index)} className={index === featuredIndex ? "home-hero__dot home-hero__dot--active" : "home-hero__dot"} aria-label={`Show featured image ${index + 1}`} />)}</div>}
              </>
            ) : (
              <div className="home-hero__visual-empty"><span>Featured gallery</span><strong>Add images to gallery/featured</strong><small>They will appear here automatically.</small></div>
            )}
          </div>
        </div>
      </header>

      {/* ── Raksha Bandhan campaign ── */}
      <section className="px-4 mb-10 animate-fade-in-up" style={{ animationDelay: "280ms" }}>
        <div className="mx-auto flex w-full max-w-3xl flex-col items-start gap-4 rounded-3xl border border-rose-400/30 bg-gradient-to-r from-[#3d101d] via-[#561328] to-[#3d101d] p-4 shadow-[0_14px_45px_rgba(190,24,93,.15)] sm:flex-row sm:items-center sm:justify-between sm:p-5">
          <div className="flex items-start gap-3">
            <div className="grid h-11 w-11 flex-shrink-0 place-items-center rounded-2xl border border-amber-300/40 bg-amber-200/10 text-amber-300">
              <Gift className="h-5 w-5" />
            </div>
            <div>
              <p className="text-[12px] font-semibold uppercase tracking-[0.2em] text-amber-300">Raksha Bandhan Offers Live</p>
              <h2 className="mt-1 font-serif text-lg font-bold text-rose-50 sm:text-xl">Free gifts on purchases above ₹15,000</h2>
              <p className="mt-1 flex items-center gap-1.5 text-xs text-rose-100/65"><CalendarDays className="h-3.5 w-3.5" /> Valid 20 Aug – 29 Aug</p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setLocation("/raksha-bandhan-offers")}
            className="inline-flex min-h-10 w-full items-center justify-center gap-2 rounded-xl border border-amber-200/70 bg-gradient-to-r from-amber-200 to-amber-400 px-4 py-2.5 text-xs font-bold text-rose-950 transition hover:brightness-105 active:scale-[.98] sm:w-auto"
          >
            See Raksha Offers <ChevronRight className="h-4 w-4" />
          </button>
        </div>
      </section>

      {/* ── Local shopping context ── */}
      <section className="mx-auto mb-8 max-w-3xl px-4 text-center">
        <p className="text-xs leading-relaxed text-muted-foreground sm:text-sm">
          Your local destination for mobile phones, tablets, smartphone covers, chargers, earphones, screen protectors and genuine accessories in Powai, Mumbai. Explore popular brands including Apple, Samsung, Xiaomi, Google, Motorola, Vivo, Sony, Realme, Nokia and Itel.
        </p>
      </section>

      {/* ── Feature pills ── */}
      <section className="flex flex-wrap justify-center gap-3 px-4 mb-12 animate-fade-in" style={{ animationDelay: "300ms" }}>
        {features.map(({ Icon, label, desc }) => (
          <div key={label} className="gold-border-glow flex items-center gap-3 bg-card rounded-2xl px-4 sm:px-5 py-3 w-full sm:w-auto max-w-xs sm:max-w-none">
            <Icon className="w-5 h-5 flex-shrink-0 text-[hsl(45_75%_50%)]" />
            <div className="text-left">
              <p className="text-sm font-semibold text-foreground leading-none">{label}</p>
              <p className="text-xs text-muted-foreground mt-0.5">{desc}</p>
            </div>
          </div>
        ))}
      </section>

      {/* ── Mobile Brands ── */}
      <section className="px-4 max-w-4xl mx-auto mb-10">
        <h2 className="text-center text-xs tracking-[0.25em] uppercase text-[hsl(45_75%_50%)] mb-8 animate-fade-in" style={{ animationDelay: "350ms" }}>
          Browse by brands
        </h2>
        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-3 sm:gap-4">
          {mobileBrands.map(({ name, slug, logo, icon, color, status }, i) => (
            <button
              type="button"
              key={name}
              data-testid={`brand-card-${name.toLowerCase()}`}
              onClick={() => setLocation(`/brand/${slug}`)}
              className="brand-card gold-border-glow bg-card rounded-2xl flex flex-col items-center justify-center gap-2 p-3 sm:p-4 cursor-pointer text-left animate-scale-in"
              style={{ animationDelay: `${80 + i * 40}ms` }}
              aria-label={`Open ${name} brand page`}
            >
              <BrandLogo name={name} color={color} size={28} icon={icon} logo={logo} />
            </button>
          ))}
        </div>
      </section>

      {/* ── Accessories ── */}
      <section className="px-4 max-w-4xl mx-auto mb-16">
        <div className="flex items-center gap-3 justify-center mb-8">
          <div className="h-px flex-1 max-w-16" style={{ background: "hsl(45 75% 50% / 0.3)" }} />
          <div className="flex items-center gap-2">
            <Headphones className="w-4 h-4 text-[hsl(45_75%_50%)]" />
            <h2 className="text-[12px] sm:text-xs tracking-[0.2em] sm:tracking-[0.25em] uppercase text-[hsl(45_75%_50%)]">
              Accessories &amp; Screen Protectors
            </h2>
          </div>
          <div className="h-px flex-1 max-w-16" style={{ background: "hsl(45 75% 50% / 0.3)" }} />
        </div>
        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-2 sm:gap-3">
          {accessoryBrands.map(({ name, slug, logo, icon, color }, i) => (
            <button
              type="button"
              key={name}
              data-testid={`accessory-card-${name.toLowerCase()}`}
              onClick={() => setLocation(`/brand/${slug}`)}
              className="brand-card animate-scale-in flex flex-col items-center justify-center gap-2 p-2.5 sm:p-3 rounded-2xl cursor-pointer text-left"
              style={{ animationDelay: `${80 + i * 40}ms`, background: "hsl(0 0% 10%)", border: "1px solid hsl(45 75% 50% / 0.12)" }}
              aria-label={`Open ${name} brand page`}
            >
              <BrandLogo name={name} color={color} size={24} icon={icon} logo={logo} />
              <span className="text-[12px] text-muted-foreground font-medium tracking-wide text-center">{name}</span>
            </button>
          ))}
        </div>
      </section>

      {/* ── Contact CTA ── */}
      <section className="flex flex-col items-center pb-16 px-4 animate-fade-in-up" style={{ animationDelay: "500ms" }}>
        <div className="w-full max-w-md rounded-3xl p-px" style={{ background: "linear-gradient(135deg,#b8942a,#fde68a,#b8942a)" }}>
          <div className="bg-card rounded-3xl p-6 sm:p-8 text-center">
            <p className="text-muted-foreground text-sm mb-2">Ready to find your next device?</p>
            <h3 className="text-xl sm:text-2xl font-serif font-semibold text-foreground mb-6">Get in Touch</h3>
            <button
              data-testid="button-contact"
              onClick={() => setLocation("/contact")}
              className="contact-btn w-full flex items-center justify-center gap-2 rounded-xl px-8 py-4 font-semibold text-sm transition-opacity hover:opacity-90"
              style={{ background: "linear-gradient(135deg,#b8942a 0%,#f0c040 50%,#b8942a 100%)", color: "#0f0f0f" }}
            >
              Contact Us <ChevronRight className="w-4 h-4" />
            </button>
            <div className="mt-6 flex flex-col gap-2 text-xs text-muted-foreground">
              <div className="flex items-center justify-center gap-2">
                <Phone className="w-3.5 h-3.5 text-[hsl(45_75%_50%)]" />
                <span>+91 9892139878 / +91 9004149999</span>
              </div>
              <div className="flex items-center justify-center gap-2 text-center">
                <MapPin className="w-3.5 h-3.5 flex-shrink-0 text-[hsl(45_75%_50%)]" />
                <span>Galleria Mall, Hiranandani Gardens, Powai</span>
              </div>
            </div>
          </div>
        </div>
        <a
          href="https://www.instagram.com/newabrakadabra70"
          target="_blank"
          rel="noopener noreferrer"
          data-testid="link-instagram"
          className="mt-6 flex items-center gap-2 text-sm text-muted-foreground hover:text-[hsl(45_75%_62%)] transition-colors"
        >
          <SiInstagram className="w-4 h-4" />
          @newabrakadabra70
        </a>
      </section>

    </div>
  );
}
