import { useLocation } from "wouter";
import { Phone, Mail, MapPin, ArrowLeft, ArrowRight, Clock, PhoneCall, Smartphone, Tablet, Headphones, ShieldCheck, ExternalLink } from "lucide-react";
import { SiWhatsapp } from "react-icons/si";

const contactItems = [
  {
    Icon: Phone,
    label: "Mobile",
    phoneLinks: [
      { label: "+91 9892139878", href: "tel:+919892139878" },
      { label: "+91 9004149999", href: "tel:+919004149999" },
    ],
    note: null,
    testId: "link-phone",
  },
  {
    Icon: PhoneCall,
    label: "Landline",
    value: "+91 22 25797924",
    href: "tel:+912225797924",
    note: null,
    testId: "link-landline",
  },
  {
    Icon: SiWhatsapp,
    label: "WhatsApp",
    value: "Chat with us on WhatsApp",
    href: "https://wa.me/919892139878",
    note: null,
    testId: "link-whatsapp",
  },
  {
    Icon: Mail,
    label: "Email",
    value: "hirji.newabrakadabra@gmail.com",
    href: "mailto:hirji.newabrakadabra@gmail.com",
    note: null,
    testId: "link-email",
  },
  {
    Icon: MapPin,
    label: "Location",
    value:
      "Shop No. 70, Galleria Shopping Mall,\nHiranandani Gardens, Powai,\nMumbai — 400072",
    href: "https://maps.app.goo.gl/YZdUBwiV8yLdZA5PA",
    note: null,
    testId: "link-address",
  },
  {
    Icon: Clock,
    label: "Hours",
    value: "Open 10AM – 10PM, All Days\n(Sat & Sun too!)",
    href: null,
    note: null,
    testId: "text-hours",
  },
];

export default function Contact() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      {/* Radial glow */}
      <div
        className="pointer-events-none fixed inset-0"
        style={{
          background:
            "radial-gradient(ellipse 50% 35% at 50% 0%, hsl(45 75% 50% / 0.12) 0%, transparent 70%)",
        }}
      />

      <div className="relative contact-page mx-auto px-4 pt-12 pb-20">
        {/* Back */}
        <button
          data-testid="button-back-home"
          onClick={() => setLocation("/")}
          className="flex items-center gap-2 text-sm text-muted-foreground hover:text-[hsl(45_75%_62%)] transition-colors mb-10"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Home
        </button>

        {/* Reference-inspired full-width contact hero */}
        <div className="contact-hero">
          <div className="contact-hero__copy">
            <div className="contact-hero__eyebrow"><span>Get in touch</span><i /></div>
            <h1>Contact <em>Us</em></h1>
            <p>Reach out to us for any queries, product information or assistance. We’re here to help!</p>
          </div>
          <div className="contact-hero__visual"><img src={`${import.meta.env.BASE_URL}contact-hero.png`} alt="Premium smartphone, wireless earbuds, and smartwatch arranged on a dark desk" /><div className="contact-hero__visual-glow" /></div>
        </div>

        <div className="contact-category-rail" aria-label="What we help with">
          <span><Smartphone /><b>Mobile<br />Phones</b></span><span><Tablet /><b>Tablets</b></span><span><Headphones /><b>Accessories</b></span><span><ShieldCheck /><b>Covers</b></span>
        </div>

        <div className="contact-layout">
          <div className="contact-info-column">
        {/* Contact cards */}
        <div className="contact-cards">
          {contactItems.map(({ Icon, label, value, phoneLinks, href, note, testId }, i) => {
            const inner = (
              <div
                className="gold-border-glow bg-card rounded-2xl flex items-start gap-4 px-4 sm:px-5 py-4 brand-card"
                style={{ animationDelay: `${i * 70}ms` }}
              >
                <div
                  className="mt-0.5 w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
                  style={{
                    background: "linear-gradient(135deg,hsl(45 75% 16%),hsl(45 75% 26%))",
                  }}
                >
                  <Icon className="w-4 h-4 text-[hsl(45_75%_62%)]" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="contact-card__label text-[12px] uppercase tracking-widest text-muted-foreground mb-0.5">
                    {label}
                  </p>
                  {phoneLinks ? (
                    <div className="flex flex-col gap-1">
                      {phoneLinks.map((phone) => (
                        <a
                          key={phone.href}
                          href={phone.href}
                          data-testid={`${testId}-${phone.label.replace(/\D/g, "")}`}
                          className="w-fit text-sm font-medium text-foreground leading-snug hover:text-[hsl(45_75%_62%)] underline-offset-2 hover:underline"
                        >
                          {phone.label}
                        </a>
                      ))}
                    </div>
                  ) : (
                    <p className="contact-card__value text-sm font-medium text-foreground leading-snug whitespace-pre-line break-words">
                      {value}
                    </p>
                  )}
                  {note && (
                    <p className="text-[12px] text-muted-foreground italic mt-1">{note}</p>
                  )}
                  {(label === "WhatsApp" || label === "Email") && (
                    <span className="contact-inline-cta">{label === "WhatsApp" ? "Open Chat" : "Send Email"}<ArrowRight aria-hidden="true" /></span>
                  )}
                </div>
                {(href || phoneLinks) && <ArrowRight className="contact-card__arrow" aria-hidden="true" />}
              </div>
            );

            return href && !phoneLinks ? (
              <a
                key={label}
                href={href}
                target={href.startsWith("http") ? "_blank" : undefined}
                rel="noopener noreferrer"
                data-testid={testId}
                className="block no-underline"
              >
                {inner}
              </a>
            ) : (
              <div key={label} data-testid={testId}>
                {inner}
              </div>
            );
          })}
        </div>
          </div>

          <div className="contact-action-column">
        {/* Find Us Easily + directions */}
        <div className="contact-map-card">
          <img src={`${import.meta.env.BASE_URL}contact-map.png`} alt="Dark isometric map with a gold route pin" />
          <div className="contact-map-card__overlay" />
          <div className="contact-map-card__copy"><MapPin /><div><h2>Find Us Easily</h2><p>Get directions to our store from your preferred maps.</p></div></div>
          <div className="contact-actions contact-map-card__actions">
            <a href="https://maps.app.goo.gl/YZdUBwiV8yLdZA5PA" target="_blank" rel="noopener noreferrer" data-testid="link-get-directions" className="contact-map-card__google"><img className="contact-map-service-icon" src={`${import.meta.env.BASE_URL}google-maps-icon.png`} alt="" aria-hidden="true" /> Google Maps <ExternalLink className="w-4 h-4 ml-auto" /></a>
            <a href="https://maps.apple.com/?address=121-122,%20Central%20Avenue,%20Galleria%20Shopping%20Mall,%20Hiranandani%20Gardens,%20Powai,%20Mumbai,%20400076&ll=19.119414,72.911844&q=New%20Abra%20Ka%20Dabra" target="_blank" rel="noopener noreferrer" data-testid="link-apple-maps" className="contact-map-card__apple"><img className="contact-map-service-icon" src={`${import.meta.env.BASE_URL}apple-maps-icon.png`} alt="" aria-hidden="true" /> Apple Maps <ExternalLink className="w-4 h-4 ml-auto" /></a>
          </div>
        </div>

          </div>
        </div>
      </div>
    </div>
  );
}
