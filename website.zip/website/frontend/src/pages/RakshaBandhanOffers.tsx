import { ArrowLeft, CalendarDays, Check, ChevronLeft, ChevronRight, Construction, Gift, MapPin, Phone, ShoppingBag, Umbrella, Watch, X, ZoomIn } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { useLocation } from "wouter";

type GalleryImage = { name: string; url: string; folder: string };

const offerGifts = [
  { Icon: Watch, title: "Free Smart Watch", detail: "A complimentary watch worth ₹3,000", accent: "#fbbf24" },
  { Icon: ShoppingBag, title: "Free Branded Bag", detail: "Carry your new tech in style", accent: "#fb7185" },
  { Icon: Umbrella, title: "Free Umbrella", detail: "A practical gift for every monsoon day", accent: "#60a5fa" },
];

export default function RakshaBandhanOffers() {
  const [, setLocation] = useLocation();
  const [galleryImages, setGalleryImages] = useState<GalleryImage[]>([]);
  const [galleryLoading, setGalleryLoading] = useState(true);
  const [selectedIndex, setSelectedIndex] = useState<number | null>(null);
  const touchStartX = useRef<number | null>(null);

  useEffect(() => {
    let active = true;
    fetch("/api/gallery", { headers: { Accept: "application/json" } })
      .then((response) => response.ok ? response.json() : { images: [] })
      .then((data) => {
        if (!active) return;
        const images = Array.isArray(data.images) ? data.images : [];
        setGalleryImages(images
          .filter((image: GalleryImage) => image.folder === "Raksha Bandhan 2026")
          .sort((a: GalleryImage, b: GalleryImage) => a.name.localeCompare(b.name)));
        setGalleryLoading(false);
      })
      .catch(() => setGalleryLoading(false));
    return () => { active = false; };
  }, []);

  const closeViewer = () => setSelectedIndex(null);
  const showPrevious = () => setSelectedIndex((current) => current === null ? null : (current - 1 + galleryImages.length) % galleryImages.length);
  const showNext = () => setSelectedIndex((current) => current === null ? null : (current + 1) % galleryImages.length);

  useEffect(() => {
    if (selectedIndex === null) return;
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") closeViewer();
      if (event.key === "ArrowLeft") showPrevious();
      if (event.key === "ArrowRight") showNext();
    };
    window.addEventListener("keydown", onKeyDown);
    document.body.style.overflow = "hidden";
    return () => { window.removeEventListener("keydown", onKeyDown); document.body.style.overflow = ""; };
  }, [selectedIndex, galleryImages.length]);

  const selectedImage = selectedIndex === null ? null : galleryImages[selectedIndex];

  return (
    <div className="min-h-screen overflow-x-hidden bg-[#160b12] text-[#fff7ed]">
      <div className="offer-page__glow" aria-hidden="true" />
      <main className="relative mx-auto w-full max-w-6xl px-4 pb-16 pt-10 sm:px-6 lg:px-10 lg:pt-14">
        <button type="button" onClick={() => setLocation("/")} className="mb-7 inline-flex items-center gap-2 rounded-full border border-amber-300/30 bg-black/20 px-4 py-2 text-sm text-amber-100 transition hover:bg-amber-200/10"><ArrowLeft className="h-4 w-4" /> Back to Home</button>

        <section className="grid items-center gap-8 lg:grid-cols-[1.05fr_.95fr] lg:gap-14">
          <div className="text-center lg:text-left">
            <p className="mb-4 inline-flex items-center gap-2 rounded-full border border-amber-300/40 bg-amber-300/10 px-4 py-2 text-[12px] font-semibold uppercase tracking-[0.24em] text-amber-200"><Gift className="h-4 w-4" /> Raksha Bandhan Special</p>
            <h1 className="font-serif text-4xl font-bold leading-[1.05] text-amber-200 drop-shadow-[0_1px_2px_rgba(251,191,36,.20)] sm:text-6xl">Celebrate the bond. Upgrade together.</h1>
            <p className="mx-auto mt-5 max-w-xl text-base leading-relaxed text-rose-100/75 lg:mx-0 sm:text-lg">This Raksha Bandhan, bring home the latest mobile, tablet, and accessory essentials from New Abra Ka Dabra—and take home three thoughtful gifts on us.</p>
            <div className="mt-7 flex flex-wrap justify-center gap-3 lg:justify-start"><div className="inline-flex items-center gap-2 rounded-xl border border-amber-300/30 bg-amber-200/10 px-4 py-3 text-sm font-semibold text-amber-100"><CalendarDays className="h-4 w-4 text-amber-300" /> 20 Aug – 29 Aug</div><div className="inline-flex items-center gap-2 rounded-xl border border-amber-300/30 bg-amber-200/10 px-4 py-3 text-sm font-semibold text-amber-100"><ShoppingBag className="h-4 w-4 text-amber-300" /> Purchase above ₹15,000</div></div>
          </div>

          <div className="offer-poster-frame mx-auto w-full max-w-2xl overflow-hidden">
            {galleryLoading ? (
              <div className="raksha-carousel-skeleton"><span /><span /><span /></div>
            ) : galleryImages.length > 0 ? (
              <div className="raksha-carousel" aria-label="Raksha Bandhan 2026 gallery">
                <div className="raksha-carousel__track">
                  {[...galleryImages, ...galleryImages].map((image, index) => {
                    const actualIndex = index % galleryImages.length;
                    return <button type="button" key={`${image.url}-${index}`} className="raksha-carousel__slide group" onClick={() => setSelectedIndex(actualIndex)} aria-label={`Open Raksha Bandhan image ${actualIndex + 1}`}><img src={image.url} alt={`Raksha Bandhan 2026 campaign ${actualIndex + 1}`} loading={index < galleryImages.length ? "eager" : "lazy"} /><span className="raksha-carousel__zoom"><ZoomIn className="h-5 w-5" /></span></button>;
                  })}
                </div>
                <div className="raksha-carousel__meta"><span>Raksha Bandhan 2026 gallery</span><span>{galleryImages.length} campaign photos · Click to enlarge</span></div>
              </div>
            ) : (
              <div className="flex min-h-64 flex-col items-center justify-center gap-3 rounded-[1.4rem] bg-black/20 px-6 text-center text-sm text-rose-100/60"><Construction className="h-8 w-8 text-amber-300/70" />Add images to gallery/Raksha Bandhan 2026 to display the campaign carousel here.</div>
            )}
          </div>
        </section>

        <section className="mt-14 text-center"><p className="text-xs font-semibold uppercase tracking-[0.28em] text-amber-300">Your Raksha Bandhan gifts</p><h2 className="mt-3 font-serif text-3xl font-bold text-white sm:text-4xl">Three gifts. One memorable upgrade.</h2><p className="mx-auto mt-3 max-w-2xl text-sm leading-relaxed text-rose-100/65 sm:text-base">Shop for the people you love, discover your next device, and enjoy a little extra celebration from our family store to yours.</p><div className="mt-8 grid gap-4 sm:grid-cols-3">{offerGifts.map(({ Icon, title, detail, accent }) => <article key={title} className="offer-gift-card"><div className="offer-gift-card__icon" style={{ color: accent, borderColor: `${accent}55`, background: `${accent}18` }}><Icon className="h-6 w-6" /></div><h3 className="mt-5 text-lg font-semibold text-white">{title}</h3><p className="mt-2 text-sm leading-relaxed text-rose-100/65">{detail}</p></article>)}</div></section>

        <section className="offer-terms mt-12 grid gap-6 lg:grid-cols-[1fr_auto] lg:items-center"><div><p className="text-xs font-semibold uppercase tracking-[0.24em] text-amber-300">How to claim</p><h2 className="mt-2 font-serif text-2xl font-bold text-white">Visit us during the offer period.</h2><div className="mt-5 grid gap-3 text-sm text-rose-100/75 sm:grid-cols-2"><p className="flex items-start gap-2"><Check className="mt-0.5 h-4 w-4 flex-shrink-0 text-emerald-400" />Choose your device or accessories.</p><p className="flex items-start gap-2"><Check className="mt-0.5 h-4 w-4 flex-shrink-0 text-emerald-400" />Complete a purchase above ₹15,000.</p><p className="flex items-start gap-2"><Check className="mt-0.5 h-4 w-4 flex-shrink-0 text-emerald-400" />Collect your three complimentary gifts.</p><p className="flex items-start gap-2"><Check className="mt-0.5 h-4 w-4 flex-shrink-0 text-emerald-400" />Ask our team about gift availability.</p></div></div><div className="rounded-2xl border border-amber-300/20 bg-black/20 p-5 text-sm text-rose-100/75 lg:min-w-72"><p className="flex items-start gap-2"><MapPin className="mt-0.5 h-4 w-4 flex-shrink-0 text-amber-300" />Galleria Mall, Hiranandani Gardens, Powai</p><p className="mt-3 flex items-start gap-2"><Phone className="mt-0.5 h-4 w-4 flex-shrink-0 text-amber-300" />+91 9892139878</p><p className="mt-4 text-xs text-rose-100/50">Offer valid from 20 Aug to 29 Aug. Gifts are subject to availability.</p></div></section>
        <div className="mt-10 text-center"><button type="button" onClick={() => setLocation("/contact")} className="offer-cta">Enquire about the offer</button></div>
      </main>

      {selectedImage && selectedIndex !== null && <div className="raksha-lightbox fixed inset-0 z-50 flex items-center justify-center bg-black/90 p-4 backdrop-blur-md" onClick={closeViewer} onTouchStart={(event) => { touchStartX.current = event.changedTouches[0]?.clientX ?? null; }} onTouchEnd={(event) => { const start = touchStartX.current; const end = event.changedTouches[0]?.clientX ?? null; touchStartX.current = null; if (start === null || end === null || Math.abs(end - start) < 45) return; if (end < start) showNext(); else showPrevious(); }}>
        <button type="button" className="absolute right-4 top-4 z-10 flex h-10 w-10 items-center justify-center rounded-full bg-white/10" onClick={closeViewer} aria-label="Close image"><X className="h-5 w-5 text-amber-200" /></button>
        <button type="button" className="absolute left-3 top-1/2 z-10 hidden -translate-y-1/2 rounded-full bg-white/10 p-3 text-amber-200 transition hover:bg-white/20 sm:block" onClick={(event) => { event.stopPropagation(); showPrevious(); }} aria-label="Previous image"><ChevronLeft /></button>
        <img src={selectedImage.url} alt={`Raksha Bandhan 2026 image ${selectedIndex + 1}`} className="max-h-[86vh] max-w-[92vw] rounded-2xl object-contain shadow-[0_0_60px_rgba(251,191,36,.18)]" onClick={(event) => event.stopPropagation()} />
        <button type="button" className="absolute right-3 top-1/2 z-10 hidden -translate-y-1/2 rounded-full bg-white/10 p-3 text-amber-200 transition hover:bg-white/20 sm:block" onClick={(event) => { event.stopPropagation(); showNext(); }} aria-label="Next image"><ChevronRight /></button>
        <p className="absolute bottom-5 left-1/2 -translate-x-1/2 rounded-full bg-black/50 px-4 py-2 text-xs text-amber-100">{selectedIndex + 1} / {galleryImages.length} · Swipe to browse</p>
      </div>}
    </div>
  );
}
