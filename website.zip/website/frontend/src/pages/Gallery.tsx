import { useEffect, useMemo, useState } from "react";
import { AlertCircle, ChevronLeft, ChevronRight, FolderOpen, Images, X, ZoomIn } from "lucide-react";

interface GalleryImage {
  name: string;
  url: string;
  folder: string;
}

function formatName(filename: string): string {
  return filename.replace(/\.[a-zA-Z0-9]+$/, "").replace(/[-_]/g, " ").replace(/\s+/g, " ").trim().replace(/\b\w/g, (c) => c.toUpperCase());
}

function formatFolder(folder: string): string {
  return folder
    .split("/")
    .filter(Boolean)
    .map(formatName)
    .join(" / ");
}

async function fetchImages(): Promise<GalleryImage[]> {
  const response = await fetch("/api/gallery", { headers: { Accept: "application/json" } });
  if (!response.ok) throw new Error(`Gallery request failed with ${response.status}`);
  const data = await response.json();
  return Array.isArray(data.images) ? data.images : [];
}

export default function Gallery() {
  const [images, setImages] = useState<GalleryImage[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [selectedFolder, setSelectedFolder] = useState("all");
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  useEffect(() => {
    let active = true;
    setLoading(true);
    setError(false);

    fetchImages()
      .then((galleryImages) => {
        if (!active) return;
        setImages(
          galleryImages
            .filter((image) => image.folder !== "featured")
            .sort((a, b) => `${a.folder}/${a.name}`.localeCompare(`${b.folder}/${b.name}`)),
        );
        setLoading(false);
      })
      .catch(() => {
        if (!active) return;
        setError(true);
        setLoading(false);
      });

    return () => {
      active = false;
    };
  }, []);

  const folders = useMemo(() => {
    const counts = new Map<string, number>();
    images.forEach(({ folder }) => {
      if (folder) counts.set(folder, (counts.get(folder) || 0) + 1);
    });
    return [...counts.entries()]
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([id, count]) => ({ id, label: formatFolder(id), count }));
  }, [images]);

  const rootImages = images.filter(({ folder }) => !folder);
  const visibleImages = selectedFolder === "all"
    ? rootImages
    : images.filter(({ folder }) => folder === selectedFolder);
  const lightboxImage = lightboxIndex === null ? null : visibleImages[lightboxIndex];
  const showPrevious = () => setLightboxIndex((current) => current === null ? null : (current - 1 + visibleImages.length) % visibleImages.length);
  const showNext = () => setLightboxIndex((current) => current === null ? null : (current + 1) % visibleImages.length);

  return (
    <div className="min-h-screen overflow-x-hidden bg-background pb-20 text-foreground">
      <div
        className="pointer-events-none fixed inset-0"
        style={{ background: "radial-gradient(ellipse 60% 30% at 50% 0%, hsl(45 75% 50% / 0.10) 0%, transparent 65%)" }}
      />

      <div className="relative px-4 pb-8 pt-14 text-center">
        <p className="mb-3 text-xs uppercase tracking-[0.3em] text-[hsl(45_75%_50%)]">Our Shop</p>
        <h1 className="font-serif text-4xl font-bold gold-text">Gallery</h1>
        <div className="mx-auto mt-4 h-px w-24" style={{ background: "linear-gradient(90deg, transparent, hsl(45 75% 50% / 0.6), transparent)" }} />
        <p className="mt-4 text-sm text-muted-foreground">Browse all store pictures or explore a specific collection.</p>
      </div>

      {loading && (
        <div className="gallery-loading-state mx-auto max-w-6xl px-4">
          <div className="gallery-loading-sidebar"><span className="skeleton-line skeleton-line--short" /><span className="skeleton-block" /><span className="skeleton-block" /></div>
          <div className="gallery-loading-grid" aria-label="Loading gallery images"><span /><span /><span /><span /><span /></div>
          <p className="text-center text-sm text-muted-foreground">Loading gallery folders…</p>
        </div>
      )}

      {error && (
        <div className="flex flex-col items-center justify-center gap-3 py-24 text-muted-foreground">
          <AlertCircle className="h-8 w-8" />
          <p className="text-sm">Could not load gallery folders. Please try again later.</p>
        </div>
      )}

      {!loading && !error && images.length === 0 && (
        <div className="flex flex-col items-center justify-center gap-3 py-24 text-muted-foreground">
          <Images className="h-8 w-8" />
          <p className="text-sm">No images found in the gallery yet.</p>
        </div>
      )}

      {!loading && !error && images.length > 0 && (
        <div className="relative mx-auto flex max-w-6xl flex-col gap-6 px-4 lg:flex-row lg:items-start lg:gap-8">
          <aside className="w-full flex-shrink-0 lg:sticky lg:top-24 lg:w-56">
            <div className="mb-3 flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.2em] text-[hsl(45_75%_62%)]">
              <FolderOpen className="h-4 w-4" /> Picture Folders
            </div>
            <nav className="flex gap-2 overflow-x-auto pb-2 lg:flex-col lg:overflow-visible" aria-label="Gallery folders">
              <button
                type="button"
                onClick={() => setSelectedFolder("all")}
                className={`gallery-folder-button ${selectedFolder === "all" ? "gallery-folder-button--active" : ""}`}
              >
                <span className="flex min-w-0 items-center gap-2"><Images className="h-4 w-4 flex-shrink-0" /> All Pictures</span>
                <span className="gallery-folder-count">{rootImages.length}</span>
              </button>
              {folders.map(({ id, label, count }) => (
                <button
                  type="button"
                  key={id}
                  onClick={() => setSelectedFolder(id)}
                  className={`gallery-folder-button ${selectedFolder === id ? "gallery-folder-button--active" : ""}`}
                  title={`View ${label}`}
                >
                  <span className="flex min-w-0 items-center gap-2"><FolderOpen className="h-4 w-4 flex-shrink-0" /> <span className="truncate">{label}</span></span>
                  <span className="gallery-folder-count">{count}</span>
                </button>
              ))}
            </nav>
          </aside>

          <section className="min-w-0 flex-1" aria-live="polite">
            <div className="mb-5 flex items-end justify-between gap-4 border-b border-[hsl(45_20%_18%)] pb-3">
              <div>
                <p className="text-[12px] uppercase tracking-[0.24em] text-[hsl(45_75%_50%)]">Selected collection</p>
                <h2 className="mt-1 font-serif text-2xl font-semibold text-foreground">
                  {selectedFolder === "all" ? "All Pictures" : formatFolder(selectedFolder)}
                </h2>
              </div>
              <p className="flex items-center gap-1 text-xs text-muted-foreground">{visibleImages.length} picture{visibleImages.length === 1 ? "" : "s"} <ChevronRight className="h-3.5 w-3.5" /></p>
            </div>

            {visibleImages.length === 0 ? (
              <p className="py-20 text-center text-sm text-muted-foreground">No pictures are available in this folder yet.</p>
            ) : (
              <div className="columns-2 gap-4 space-y-4 sm:columns-3">
                {visibleImages.map((image, index) => (
                  <div key={image.url} data-testid={`gallery-img-${index}`} className="group mb-4 break-inside-avoid animate-scale-in" style={{ animationDelay: `${index * 45}ms` }}>
                    <div
                      className="relative cursor-zoom-in overflow-hidden rounded-xl"
                      style={{ border: "1px solid hsl(45 75% 50% / 0.2)" }}
                      onClick={() => setLightboxIndex(index)}
                    >
                      <img src={image.url} alt={`${image.name} — ${image.folder ? formatFolder(image.folder) : "Gallery"}`} className="w-full object-cover transition-transform duration-500 group-hover:scale-105" loading="lazy" />
                      <div className="absolute inset-0 flex items-center justify-center opacity-0 transition-opacity duration-300 group-hover:opacity-100" style={{ background: "hsl(0 0% 0% / 0.3)" }}>
                        <ZoomIn className="h-6 w-6 text-[hsl(45_75%_80%)]" />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>
        </div>
      )}

      {lightboxImage && lightboxIndex !== null && (
        <div className="gallery-lightbox fixed inset-0 z-50 flex items-center justify-center bg-black/90 p-4 backdrop-blur-md" onClick={() => setLightboxIndex(null)}>
          <button type="button" data-testid="button-lightbox-close" className="absolute right-4 top-4 z-10 flex h-10 w-10 items-center justify-center rounded-full" style={{ background: "hsl(0 0% 15%)", border: "1px solid hsl(45 75% 50% / 0.3)" }} onClick={() => setLightboxIndex(null)} aria-label="Close image"><X className="h-5 w-5 text-[hsl(45_75%_62%)]" /></button>
          {visibleImages.length > 1 && <button type="button" className="absolute left-3 top-1/2 z-10 hidden -translate-y-1/2 rounded-full bg-white/10 p-3 text-amber-200 sm:block" onClick={(event) => { event.stopPropagation(); showPrevious(); }} aria-label="Previous image"><ChevronLeft /></button>}
          <div className="max-w-[92vw] text-center" onClick={(event) => event.stopPropagation()}><img src={lightboxImage.url} alt={lightboxImage.name} className="max-h-[82vh] max-w-full rounded-2xl object-contain" style={{ boxShadow: "0 0 60px hsl(45 75% 50% / 0.2)" }} /><p className="mt-4 text-xs text-amber-100/75">{formatName(lightboxImage.name)} · {lightboxIndex + 1} / {visibleImages.length}</p></div>
          {visibleImages.length > 1 && <button type="button" className="absolute right-3 top-1/2 z-10 hidden -translate-y-1/2 rounded-full bg-white/10 p-3 text-amber-200 sm:block" onClick={(event) => { event.stopPropagation(); showNext(); }} aria-label="Next image"><ChevronRight /></button>}
        </div>
      )}
    </div>
  );
}
