import { useEffect, useRef, useState } from "react";
import { CheckCircle2, FolderPlus, Images, LogIn, LogOut, Trash2, Upload, XCircle } from "lucide-react";

type GalleryImage = { name: string; path: string; folder: string; url: string };
type Notice = { type: "success" | "error"; text: string } | null;

export default function Master() {
  const [authenticated, setAuthenticated] = useState(false);
  const [checking, setChecking] = useState(true);
  const [id, setId] = useState("");
  const [password, setPassword] = useState("");
  const [images, setImages] = useState<GalleryImage[]>([]);
  const [folders, setFolders] = useState<string[]>([]);
  const [folder, setFolder] = useState("");
  const [newFolder, setNewFolder] = useState("");
  const [notice, setNotice] = useState<Notice>(null);
  const [busy, setBusy] = useState(false);
  const [uploadKey, setUploadKey] = useState(0);
  const fileInput = useRef<HTMLInputElement>(null);

  const loadImages = async () => {
    const response = await fetch("/api/master/gallery", { credentials: "same-origin" });
    if (response.status === 401) {
      setAuthenticated(false);
      return;
    }
    const data = await response.json();
    if (!response.ok) throw new Error(data.message || "Could not load gallery.");
    setImages(data.images || []);
    setFolders(data.folders || []);
  };

  useEffect(() => {
    fetch("/api/master/status", { credentials: "same-origin" })
      .then((response) => {
        if (response.ok) {
          setAuthenticated(true);
          return loadImages();
        }
      })
      .catch(() => undefined)
      .finally(() => setChecking(false));
  }, []);

  const handleLogin = async (event: React.FormEvent) => {
    event.preventDefault();
    setBusy(true);
    setNotice(null);
    try {
      const response = await fetch("/api/master/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "same-origin",
        body: JSON.stringify({ id, password }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.message || "Login failed.");
      setAuthenticated(true);
      setPassword("");
      await loadImages();
    } catch (error) {
      setNotice({ type: "error", text: error instanceof Error ? error.message : "Login failed." });
    } finally {
      setBusy(false);
    }
  };

  const handleCreateFolder = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!newFolder.trim()) return;
    setBusy(true);
    setNotice(null);
    try {
      const response = await fetch("/api/master/folders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "same-origin",
        body: JSON.stringify({ folder: newFolder }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.message || "Folder could not be created.");
      await loadImages();
      setFolder(data.folder);
      setNewFolder("");
      setNotice({ type: "success", text: `Folder “${data.folder}” is ready.` });
    } catch (error) {
      setNotice({ type: "error", text: error instanceof Error ? error.message : "Folder could not be created." });
    } finally {
      setBusy(false);
    }
  };

  const handleUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = [...(event.target.files || [])];
    if (!files.length) return;
    setBusy(true);
    setNotice(null);
    try {
      const body = new FormData();
      body.append("folder", folder);
      files.forEach((file) => body.append("photos", file));
      const response = await fetch("/api/master/upload", { method: "POST", body, credentials: "same-origin" });
      const data = await response.json();
      if (!response.ok) throw new Error(data.message || "Upload failed.");
      setImages(data.images || []);
      setFolders(data.folders || []);
      setNotice({ type: "success", text: `${data.files.length} photo${data.files.length === 1 ? "" : "s"} uploaded successfully.` });
    } catch (error) {
      setNotice({ type: "error", text: error instanceof Error ? error.message : "Upload failed." });
    } finally {
      setBusy(false);
      setUploadKey((key) => key + 1);
    }
  };

  const handleDelete = async (image: GalleryImage) => {
    if (!window.confirm(`Delete “${image.name}”?`)) return;
    setBusy(true);
    setNotice(null);
    try {
      const response = await fetch(`/api/master/images?path=${encodeURIComponent(image.path)}`, { method: "DELETE", credentials: "same-origin" });
      const data = await response.json();
      if (!response.ok) throw new Error(data.message || "Image could not be deleted.");
      setImages((current) => current.filter((item) => item.path !== image.path));
      setNotice({ type: "success", text: "Image deleted." });
    } catch (error) {
      setNotice({ type: "error", text: error instanceof Error ? error.message : "Image could not be deleted." });
    } finally {
      setBusy(false);
    }
  };

  const handleLogout = async () => {
    await fetch("/api/master/logout", { method: "POST", credentials: "same-origin" });
    setAuthenticated(false);
    setImages([]);
    setFolders([]);
  };

  if (checking) return <div className="flex min-h-screen items-center justify-center bg-background text-sm text-muted-foreground">Checking master access…</div>;

  if (!authenticated) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background px-4 py-16 text-foreground">
        <form onSubmit={handleLogin} className="w-full max-w-md rounded-3xl border border-[hsl(45_75%_50%_/_0.3)] bg-card p-6 shadow-2xl sm:p-8">
          <div className="mb-8 text-center">
            <div className="mx-auto mb-4 grid h-14 w-14 place-items-center rounded-2xl bg-[hsl(45_75%_50%_/_0.12)] text-[hsl(45_75%_62%)]"><LogIn className="h-6 w-6" /></div>
            <p className="text-xs uppercase tracking-[0.28em] text-[hsl(45_75%_50%)]">Private access</p>
            <h1 className="mt-2 font-serif text-3xl font-bold gold-text">Master Login</h1>
            <p className="mt-3 text-sm text-muted-foreground">Manage gallery folders and upload store photos.</p>
          </div>
          {notice && <Notice notice={notice} />}
          <label className="mb-4 block text-xs uppercase tracking-wider text-muted-foreground">Master ID<input value={id} onChange={(event) => setId(event.target.value)} className="mt-2 w-full rounded-xl border border-[hsl(45_20%_22%)] bg-background px-4 py-3 text-sm outline-none focus:border-[hsl(45_75%_50%)]" autoComplete="username" required /></label>
          <label className="mb-6 block text-xs uppercase tracking-wider text-muted-foreground">Password<input type="password" value={password} onChange={(event) => setPassword(event.target.value)} className="mt-2 w-full rounded-xl border border-[hsl(45_20%_22%)] bg-background px-4 py-3 text-sm outline-none focus:border-[hsl(45_75%_50%)]" autoComplete="current-password" required /></label>
          <button type="submit" disabled={busy} className="flex min-h-12 w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[#b8942a] via-[#f0c040] to-[#b8942a] px-6 py-3 text-sm font-bold text-[#0f0f0f] disabled:opacity-60">{busy ? "Signing in…" : "Open Master Panel"}</button>
        </form>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background px-4 py-8 text-foreground sm:px-6 lg:px-10">
      <div className="mx-auto max-w-6xl">
        <header className="mb-8 flex flex-col gap-4 border-b border-[hsl(45_20%_18%)] pb-6 sm:flex-row sm:items-end sm:justify-between">
          <div><p className="text-xs uppercase tracking-[0.28em] text-[hsl(45_75%_50%)]">Private gallery control</p><h1 className="mt-2 font-serif text-3xl font-bold gold-text sm:text-4xl">Master Panel</h1><p className="mt-2 text-sm text-muted-foreground">Upload and organize photos from your phone.</p></div>
          <button type="button" onClick={handleLogout} className="inline-flex items-center justify-center gap-2 rounded-xl border border-[hsl(45_20%_25%)] px-4 py-2.5 text-sm text-muted-foreground hover:text-foreground"><LogOut className="h-4 w-4" /> Log out</button>
        </header>
        {notice && <div className="mb-6"><Notice notice={notice} /></div>}

        <div className="grid gap-6 lg:grid-cols-[280px_1fr]">
          <aside className="space-y-5">
            <section className="rounded-2xl border border-[hsl(45_20%_18%)] bg-card p-5">
              <h2 className="flex items-center gap-2 font-serif text-lg font-semibold"><FolderPlus className="h-5 w-5 text-[hsl(45_75%_62%)]" /> New folder</h2>
              <form onSubmit={handleCreateFolder} className="mt-4 flex gap-2"><input value={newFolder} onChange={(event) => setNewFolder(event.target.value)} placeholder="e.g. Raksha Bandhan" className="min-w-0 flex-1 rounded-xl border border-[hsl(45_20%_22%)] bg-background px-3 py-2.5 text-sm outline-none focus:border-[hsl(45_75%_50%)]" /><button type="submit" disabled={busy} className="rounded-xl bg-[hsl(45_75%_50%_/_0.16)] px-3 text-[hsl(45_75%_70%)]"><FolderPlus className="h-4 w-4" /></button></form>
            </section>
            <section className="rounded-2xl border border-[hsl(45_20%_18%)] bg-card p-5"><p className="mb-3 text-xs uppercase tracking-[0.2em] text-[hsl(45_75%_50%)]">Upload destination</p><select value={folder} onChange={(event) => setFolder(event.target.value)} className="w-full rounded-xl border border-[hsl(45_20%_22%)] bg-background px-3 py-3 text-sm outline-none focus:border-[hsl(45_75%_50%)]"><option value="">Root gallery</option>{folders.map((item) => <option key={item} value={item}>{item}</option>)}</select><label className="mt-4 flex min-h-12 cursor-pointer items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[#b8942a] via-[#f0c040] to-[#b8942a] px-4 text-center text-sm font-bold text-[#0f0f0f]"><Upload className="h-4 w-4" /> Choose from Photos or Files<input key={uploadKey} ref={fileInput} type="file" accept="image/*" multiple className="sr-only" onChange={handleUpload} disabled={busy} /></label><p className="mt-3 text-xs leading-relaxed text-muted-foreground">Images up to 12 MB each. You can select multiple photos from your phone.</p></section>
            <section className="rounded-2xl border border-[hsl(45_20%_18%)] bg-card p-5">
              <div className="mb-3 flex items-center justify-between gap-2"><p className="text-xs uppercase tracking-[0.2em] text-[hsl(45_75%_50%)]">Existing folders</p><span className="text-xs text-muted-foreground">{folders.length}</span></div>
              <div className="space-y-2">
                <button type="button" onClick={() => setFolder("")} className={`flex w-full items-center justify-between rounded-lg border px-3 py-2 text-left text-xs ${folder === "" ? "border-[hsl(45_75%_50%_/_0.45)] bg-[hsl(45_75%_50%_/_0.1)] text-[hsl(45_75%_80%)]" : "border-[hsl(45_20%_22%)] text-muted-foreground"}`}><span>Root gallery</span><span>{images.filter((image) => !image.folder).length}</span></button>
                {folders.map((item) => { const count = images.filter((image) => image.folder === item).length; return <button type="button" key={item} onClick={() => setFolder(item)} className={`flex w-full items-center justify-between rounded-lg border px-3 py-2 text-left text-xs ${folder === item ? "border-[hsl(45_75%_50%_/_0.45)] bg-[hsl(45_75%_50%_/_0.1)] text-[hsl(45_75%_80%)]" : "border-[hsl(45_20%_22%)] text-muted-foreground"}`}><span className="min-w-0 truncate" title={item}>{item}</span><span className={count === 0 ? "text-amber-300" : "text-muted-foreground"}>{count === 0 ? "Empty" : count}</span></button>; })}
              </div>
            </section>
          </aside>

          <section className="rounded-2xl border border-[hsl(45_20%_18%)] bg-card p-5 sm:p-6"><div className="mb-5 flex items-center justify-between gap-3"><div><p className="text-xs uppercase tracking-[0.2em] text-[hsl(45_75%_50%)]">Managed photos</p><h2 className="mt-1 font-serif text-2xl font-semibold">Gallery library</h2></div><span className="rounded-full bg-[hsl(45_75%_50%_/_0.1)] px-3 py-1 text-xs text-[hsl(45_75%_70%)]">{images.length} total</span></div>{images.length === 0 ? <div className="flex min-h-48 flex-col items-center justify-center gap-3 text-center text-sm text-muted-foreground"><Images className="h-8 w-8" />No photos uploaded yet.</div> : <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-4">{images.map((image) => <article key={image.path} className="overflow-hidden rounded-xl border border-[hsl(45_20%_20%)] bg-background"><img src={image.url} alt={image.name} className="aspect-square w-full object-cover" loading="lazy" /><div className="p-2.5"><p className="truncate text-xs font-medium" title={image.name}>{image.name}</p><p className="mt-1 truncate text-[12px] text-muted-foreground">{image.folder || "Root gallery"}</p><button type="button" onClick={() => handleDelete(image)} disabled={busy} className="mt-2 inline-flex items-center gap-1 text-xs text-red-300 hover:text-red-200"><Trash2 className="h-3.5 w-3.5" /> Delete</button></div></article>)}</div>}</section>
        </div>
      </div>
    </div>
  );
}

function Notice({ notice }: { notice: Exclude<Notice, null> }) {
  const success = notice.type === "success";
  return <div className={`flex items-start gap-2 rounded-xl border px-4 py-3 text-sm ${success ? "border-green-500/30 bg-green-500/10 text-green-300" : "border-red-500/30 bg-red-500/10 text-red-300"}`}>{success ? <CheckCircle2 className="mt-0.5 h-4 w-4 flex-shrink-0" /> : <XCircle className="mt-0.5 h-4 w-4 flex-shrink-0" />}{notice.text}</div>;
}
