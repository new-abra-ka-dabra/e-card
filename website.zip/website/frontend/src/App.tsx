import { Switch, Route, useLocation } from "wouter";
import { lazy, Suspense } from "react";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import SiteFooter from "@/components/SiteFooter";
import Nav from "@/components/Nav";
import OfferAnnouncement from "@/components/OfferAnnouncement";
import Seo from "@/components/Seo";
import { Router as WouterRouter } from "wouter";

const Contact = lazy(() => import("@/pages/Contact"));
const Gallery = lazy(() => import("@/pages/Gallery"));
const B2B = lazy(() => import("@/pages/B2B"));
const RakshaBandhanOffers = lazy(() => import("@/pages/RakshaBandhanOffers"));
const Master = lazy(() => import("@/pages/Master"));
const BrandApple = lazy(() => import("@/brands/apple"));
const BrandSamsung = lazy(() => import("@/brands/samsung"));
const BrandXiaomi = lazy(() => import("@/brands/xiaomi"));
const BrandGoogle = lazy(() => import("@/brands/google"));
const BrandMotorola = lazy(() => import("@/brands/motorola"));
const BrandVivo = lazy(() => import("@/brands/vivo"));
const BrandOnePlus = lazy(() => import("@/brands/oneplus"));
const BrandSony = lazy(() => import("@/brands/sony"));
const BrandRealme = lazy(() => import("@/brands/realme"));
const BrandNokia = lazy(() => import("@/brands/nokia"));
const BrandItel = lazy(() => import("@/brands/itel"));
const BrandStuffcool = lazy(() => import("@/brands/stuffcool"));
const BrandSpigen = lazy(() => import("@/brands/spigen"));
const BrandPortronics = lazy(() => import("@/brands/portronics"));
const BrandBoat = lazy(() => import("@/brands/boat"));
const BrandBose = lazy(() => import("@/brands/bose"));
const BrandAmbrane = lazy(() => import("@/brands/ambrane"));
const BrandHoneywell = lazy(() => import("@/brands/honeywell"));
const BrandDigitek = lazy(() => import("@/brands/digitek"));
const BrandMembrane = lazy(() => import("@/brands/membrane"));
const BrandLito = lazy(() => import("@/brands/lito"));
const BrandNeopack = lazy(() => import("@/brands/neopack"));

function Router() {
  const [location] = useLocation();
  const hideOfferAnnouncement = location === "/brand/apple" || location === "/brand/samsung";
  return (
    <div className="site-shell">
      <Seo />
      {location !== "/contact" && !hideOfferAnnouncement && <OfferAnnouncement />}
      <Nav />
      <Suspense fallback={<div className="flex min-h-[60vh] items-center justify-center bg-background text-sm text-muted-foreground">Loading…</div>}>
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/home" component={Home} />
          <Route path="/contact" component={Contact} />
          <Route path="/gallery" component={Gallery} />
          <Route path="/b2b" component={B2B} />
          <Route path="/raksha-bandhan-offers" component={RakshaBandhanOffers} />
          <Route path="/master" component={Master} />
          <Route path="/brand/apple" component={BrandApple} />
          <Route path="/brand/samsung" component={BrandSamsung} />
          <Route path="/brand/xiaomi" component={BrandXiaomi} />
          <Route path="/brand/google" component={BrandGoogle} />
          <Route path="/brand/motorola" component={BrandMotorola} />
          <Route path="/brand/vivo" component={BrandVivo} />
          <Route path="/brand/oneplus" component={BrandOnePlus} />
          <Route path="/brand/sony" component={BrandSony} />
          <Route path="/brand/realme" component={BrandRealme} />
          <Route path="/brand/nokia" component={BrandNokia} />
          <Route path="/brand/itel" component={BrandItel} />
          <Route path="/brand/stuffcool" component={BrandStuffcool} />
          <Route path="/brand/spigen" component={BrandSpigen} />
          <Route path="/brand/portronics" component={BrandPortronics} />
          <Route path="/brand/boat" component={BrandBoat} />
          <Route path="/brand/bose" component={BrandBose} />
          <Route path="/brand/ambrane" component={BrandAmbrane} />
          <Route path="/brand/honeywell" component={BrandHoneywell} />
          <Route path="/brand/digitek" component={BrandDigitek} />
          <Route path="/brand/membrane" component={BrandMembrane} />
          <Route path="/brand/lito" component={BrandLito} />
          <Route path="/brand/neopack" component={BrandNeopack} />
          <Route component={NotFound} />
        </Switch>
      </Suspense>
      <SiteFooter />
    </div>
  );
}

function App() {
  return (
    <TooltipProvider>
      <WouterRouter>
        <Router />
      </WouterRouter>
      <Toaster />
    </TooltipProvider>
  );
}

export default App;
