# Desktop UI redesign references

The PC layout was changed from a phone-like centered frame to a wider desktop app shell with a persistent horizontal navigation header. The mobile layout continues to use the hamburger drawer.

## Design decisions

The desktop header uses a brand block on the left, four primary destinations in a left-to-right row, and a compact Raksha Offers action on the right. Active navigation uses a gold pill-like state, while the mobile drawer remains available below the desktop breakpoint.

The desktop shell expands to a 1440px maximum width, and previously narrow content containers receive wider limits at desktop sizes. This keeps the premium dark-and-gold identity while reducing the impression that the visitor is viewing a tall phone screen inside a PC browser.

## Sources

1. MDN, Responsive web design: https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/CSS_layout/Responsive_Design

   The implementation follows MDN’s guidance to use flexible layouts, media queries, and content-led breakpoints instead of designing around a small fixed device frame.

2. web.dev, Responsive web design basics: https://web.dev/articles/responsive-web-design-basics

   The implementation uses a single-column mobile layout and wider flexible desktop content, while avoiding horizontal overflow and retaining responsive image behavior.

3. Material Design 3, Navigation bar: https://m3.material.io/components/navigation-bar

   The four stable primary destinations follow the guidance that navigation destinations should remain consistent and that horizontal navigation is appropriate when more width is available.

4. Apple Human Interface Guidelines, Navigation and search: https://developer.apple.com/design/human-interface-guidelines/navigation-and-search

   The desktop header provides persistent navigation and clear active-state orientation, while the mobile drawer remains a compact navigation pattern for smaller screens.
