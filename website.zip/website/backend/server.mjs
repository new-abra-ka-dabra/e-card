import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { saveInquiry } from "./inquiry-store.mjs";
import { createMasterGallery } from "./master-gallery.mjs";
import { resolveOfferImage, scanOfferImages } from "./offer-assets.mjs";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const projectRoot = path.resolve(__dirname, "..");
const docsDir = path.join(projectRoot, "docs");
const port = Number(process.env.PORT || 5000);
const masterGallery = createMasterGallery({ rootDir: projectRoot });

const mimeTypes = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".svg": "image/svg+xml",
  ".webp": "image/webp",
  ".ico": "image/x-icon",
};

function sendJson(response, status, body) {
  response.writeHead(status, { "Content-Type": "application/json; charset=utf-8" });
  response.end(JSON.stringify(body));
}

function readBody(request) {
  return new Promise((resolve, reject) => {
    let body = "";
    request.setEncoding("utf8");
    request.on("data", (chunk) => {
      body += chunk;
      if (body.length > 100_000) reject(new Error("Request too large"));
    });
    request.on("end", () => resolve(body));
    request.on("error", reject);
  });
}

function serveStatic(request, response) {
  const requestedPath = decodeURIComponent(new URL(request.url, `http://${request.headers.host}`).pathname);
  const relativePath = requestedPath === "/" ? "index.html" : requestedPath.replace(/^\/+/, "");
  const candidate = path.resolve(docsDir, relativePath);
  const safeCandidate = candidate.startsWith(docsDir) ? candidate : path.join(docsDir, "index.html");
  const filePath = fs.existsSync(safeCandidate) && fs.statSync(safeCandidate).isFile()
    ? safeCandidate
    : path.join(docsDir, "index.html");

  if (!fs.existsSync(filePath)) {
    response.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
    response.end("Build the site first with npm run build.");
    return;
  }

  const extension = path.extname(filePath).toLowerCase();
  const isHashedAsset = /[.-][A-Za-z0-9_-]{8,}\.(js|css)$/.test(filePath);
  const cacheControl = isHashedAsset || filePath.includes(`${path.sep}offers${path.sep}`) || filePath.includes(`${path.sep}logos${path.sep}`)
    ? "public, max-age=31536000, immutable"
    : filePath.endsWith("index.html")
      ? "no-cache"
      : "public, max-age=3600";
  response.writeHead(200, {
    "Content-Type": mimeTypes[extension] || "application/octet-stream",
    "Cache-Control": cacheControl,
  });
  fs.createReadStream(filePath).pipe(response);
}

const server = http.createServer(async (request, response) => {
  if (await masterGallery.handle(request, response)) return;

  if (request.method === "POST" && request.url === "/api/inquiries") {
    try {
      const data = JSON.parse(await readBody(request));
      const required = ["name", "company", "phone", "email", "brandsInterested", "message"];
      if (required.some((field) => !String(data[field] || "").trim())) {
        sendJson(response, 400, { ok: false, message: "All inquiry fields are required." });
        return;
      }
      const saved = saveInquiry(data);
      sendJson(response, 201, { ok: true, date: saved.date, time: saved.time });
    } catch (error) {
      console.error("[inquiries]", error);
      sendJson(response, 500, { ok: false, message: "Inquiry could not be saved." });
    }
    return;
  }

  if (request.method === "GET" && request.url === "/api/offers") {
    sendJson(response, 200, { ok: true, images: scanOfferImages(projectRoot) });
    return;
  }

  if (request.method === "GET" && request.url.startsWith("/offers/")) {
    const offerPath = resolveOfferImage(projectRoot, request.url.slice("/offers/".length).split("?")[0]);
    if (offerPath) {
      const extension = path.extname(offerPath).toLowerCase();
      response.writeHead(200, { "Content-Type": mimeTypes[extension] || "application/octet-stream", "Cache-Control": "public, max-age=3600" });
      fs.createReadStream(offerPath).pipe(response);
      return;
    }
  }

  if (request.method === "GET") {
    serveStatic(request, response);
    return;
  }

  response.writeHead(405, { "Content-Type": "text/plain; charset=utf-8" });
  response.end("Method Not Allowed");
});

server.listen(port, "0.0.0.0", () => {
  console.log(`New Abra Ka Dabra running at http://localhost:${port}`);
});
