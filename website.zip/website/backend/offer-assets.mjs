import fs from "node:fs";
import path from "node:path";

const IMAGE_EXTENSIONS = new Set([".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg"]);

function offerDirectories(rootDir) {
  return [
    path.join(rootDir, "frontend", "public", "offers"),
    path.join(rootDir, "public", "offers"),
    path.join(rootDir, "offers"),
  ];
}

function publicOfferUrl(relativePath) {
  return `/offers/${relativePath.split(path.sep).map(encodeURIComponent).join("/")}`;
}

export function scanOfferImages(rootDir) {
  const offerDir = offerDirectories(rootDir).find((candidate) => fs.existsSync(candidate) && fs.statSync(candidate).isDirectory());
  if (!offerDir) return [];

  const images = [];
  function walk(currentDir, relativeFolder = "") {
    for (const entry of fs.readdirSync(currentDir, { withFileTypes: true }).sort((a, b) => a.name.localeCompare(b.name))) {
      const absolute = path.join(currentDir, entry.name);
      const relative = relativeFolder ? path.join(relativeFolder, entry.name) : entry.name;
      if (entry.isDirectory()) walk(absolute, relative);
      else if (IMAGE_EXTENSIONS.has(path.extname(entry.name).toLowerCase())) {
        images.push({ name: entry.name, path: relative, url: publicOfferUrl(relative) });
      }
    }
  }

  walk(offerDir);
  return images;
}

export function resolveOfferImage(rootDir, relativePath) {
  try {
    const decoded = decodeURIComponent(String(relativePath || ""));
    const cleaned = decoded.replace(/\\/g, "/").split("/").filter((part) => part && part !== "." && part !== "..").join(path.sep);
    for (const offerDir of offerDirectories(rootDir)) {
      const candidate = path.resolve(offerDir, cleaned);
      if (!candidate.startsWith(path.resolve(offerDir))) continue;
      if (fs.existsSync(candidate) && fs.statSync(candidate).isFile() && IMAGE_EXTENSIONS.has(path.extname(candidate).toLowerCase())) return candidate;
    }
  } catch {
    return null;
  }
  return null;
}
