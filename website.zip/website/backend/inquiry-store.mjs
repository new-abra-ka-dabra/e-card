import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import XLSX from "xlsx";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const projectRoot = path.resolve(__dirname, "..");
const inquiriesDir = path.join(projectRoot, "inquiries");
const workbookPath = path.join(inquiriesDir, "inquiries.xlsx");

const columns = [
  "Date",
  "Time",
  "Name",
  "Company / Shop",
  "Phone / WhatsApp",
  "Email",
  "Brands / Products Interested In",
  "Message / Requirements",
];

export function saveInquiry(data) {
  fs.mkdirSync(inquiriesDir, { recursive: true });

  let workbook;
  if (fs.existsSync(workbookPath)) {
    workbook = XLSX.readFile(workbookPath);
  } else {
    workbook = XLSX.utils.book_new();
  }

  const sheetName = "Inquiries";
  const existingSheet = workbook.Sheets[sheetName];
  const existingRows = existingSheet
    ? XLSX.utils.sheet_to_json(existingSheet, { defval: "" })
    : [];

  const now = new Date();
  const row = {
    Date: now.toLocaleDateString("en-IN"),
    Time: now.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit", second: "2-digit" }),
    Name: data.name,
    "Company / Shop": data.company,
    "Phone / WhatsApp": data.phone,
    Email: data.email,
    "Brands / Products Interested In": data.brandsInterested,
    "Message / Requirements": data.message,
  };

  const rows = [...existingRows, row];

  const worksheet = XLSX.utils.json_to_sheet(rows, { header: columns });
  worksheet["!cols"] = [
    { wch: 13 }, { wch: 12 }, { wch: 22 }, { wch: 24 },
    { wch: 18 }, { wch: 30 }, { wch: 36 }, { wch: 60 },
  ];

  if (existingSheet) {
    workbook.Sheets[sheetName] = worksheet;
  } else {
    XLSX.utils.book_append_sheet(workbook, worksheet, sheetName);
  }

  XLSX.writeFile(workbook, workbookPath);
  return { workbookPath, date: row.Date, time: row.Time };
}
