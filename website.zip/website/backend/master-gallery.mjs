import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import Busboy from "busboy";
import sharp from "sharp";

const IMAGE_EXTENSIONS = new Set([".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg"]);
const MAX_UPLOAD_BYTES = 12 * 1024 * 1024;
const SESSION_TTL_MS = 8 * 60 * 60 * 1000;

function safeSegment(value) {
  return String(value || "")
    .replace(/\\/g, "/")
    .split("/")
    .filter((part) => part && part !== "." && part !== "..")
    .map((part) => part.replace(/[^a-zA-Z0-9 _.-]/g, "").trim())
    .filter(Boolean)
    .join(path.sep);
}

function safeFileName(value) {
  const base = path.basename(String(value || "upload"));
  const cleaned = base.replace(/[^a-zA-Z0-9 _.-]/g, "").trim() || "upload";
  return cleaned.slice(0, 120);
}

async function normalizeFeaturedImage(target, extension) {
  const rasterExtensions = new Set([".png", ".jpg", ".jpeg", ".webp"]);
  if (!rasterExtensions.has(extension)) return;
  const temporaryTarget = `${target}.normalized${extension}`;
  let pipeline = sharp(target)
    .trim({ background: { r: 0, g: 0, b: 0 }, threshold: 28 })
    .resize(1200, 620, { fit: "cover", position: "centre", withoutEnlargement: false });
  if (extension === ".jpg" || extension === ".jpeg") pipeline = pipeline.jpeg({ quality: 94, mozjpeg: true });
  else if (extension === ".png") pipeline = pipeline.png({ compressionLevel: 9 });
  else pipeline = pipeline.webp({ quality: 94 });
  await pipeline.toFile(temporaryTarget);
  fs.renameSync(temporaryTarget, target);
}

function sendJson(response, status, body) {
  response.writeHead(status, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" });
  response.end(JSON.stringify(body));
}

function parseJsonBody(request) {
  return new Promise((resolve, reject) => {
    let body = "";
    request.setEncoding("utf8");
    request.on("data", (chunk) => {
      body += chunk;
      if (body.length > 100_000) reject(new Error("Request too large"));
    });
    request.on("end", () => {
      try { resolve(JSON.parse(body || "{}")); } catch { reject(new Error("Invalid JSON")); }
    });
    request.on("error", reject);
  });
}

function readCredentials(masterDir) {
  const filePath = path.join(masterDir, "credentials.txt");
  if (!fs.existsSync(filePath)) {
    fs.mkdirSync(masterDir, { recursive: true });
    fs.writeFileSync(filePath, "id=master\npassword=change-this-password\n", { mode: 0o600 });
  }
  const values = {};
  for (const line of fs.readFileSync(filePath, "utf8").split(/\r?\n/)) {
    const separator = line.indexOf("=");
    if (separator > 0) values[line.slice(0, separator).trim()] = line.slice(separator + 1).trim();
  }
  return { id: values.id || "master", password: values.password || "change-this-password" };
}

function parseCookies(request) {
  return Object.fromEntries((request.headers.cookie || "").split(";").filter(Boolean).map((part) => {
    const index = part.indexOf("=");
    return [part.slice(0, index).trim(), decodeURIComponent(part.slice(index + 1).trim())];
  }));
}

function createMasterGallery({ rootDir }) {
  const masterDir = path.join(rootDir, "master");
  const galleryDir = path.join(rootDir, "gallery");
  const sessions = new Map();
  readCredentials(masterDir);
  fs.mkdirSync(galleryDir, { recursive: true });

  function isAuthenticated(request) {
    const token = parseCookies(request).master_session;
    const expires = token && sessions.get(token);
    if (!expires || expires < Date.now()) {
      if (token) sessions.delete(token);
      return false;
    }
    sessions.set(token, Date.now() + SESSION_TTL_MS);
    return true;
  }

  function publicImagePath(relativePath) {
    return `/gallery-assets/${relativePath.split(path.sep).map(encodeURIComponent).join("/")}`;
  }

  function scanGallery() {
    const images = [];
    const folders = new Set();
    function walk(currentDir, relativeFolder = "") {
      if (!fs.existsSync(currentDir)) return;
      if (relativeFolder) folders.add(relativeFolder);
      for (const entry of fs.readdirSync(currentDir, { withFileTypes: true }).sort((a, b) => a.name.localeCompare(b.name))) {
        const absolute = path.join(currentDir, entry.name);
        const relative = relativeFolder ? path.join(relativeFolder, entry.name) : entry.name;
        if (entry.isDirectory()) walk(absolute, relative);
        else if (IMAGE_EXTENSIONS.has(path.extname(entry.name).toLowerCase())) {
          const folder = path.dirname(relative) === "." ? "" : path.dirname(relative);
          images.push({ name: entry.name, path: relative, folder, url: publicImagePath(relative) });
        }
      }
    }
    walk(galleryDir);
    const sortedFolders = [...folders].sort((a, b) => a.localeCompare(b));
    return { folders: sortedFolders, images };
  }

  function safeGalleryPath(relativePath) {
    try {
      const decoded = decodeURIComponent(String(relativePath || ""));
      const cleaned = safeSegment(decoded);
      const absolute = path.resolve(galleryDir, cleaned);
      return absolute.startsWith(path.resolve(galleryDir)) ? absolute : null;
    } catch {
      return null;
    }
  }

  async function upload(request, response) {
    const contentType = request.headers["content-type"] || "";
    if (!contentType.startsWith("multipart/form-data")) {
      sendJson(response, 400, { ok: false, message: "Use multipart form upload." });
      return;
    }

    const busboy = Busboy({ headers: request.headers, limits: { fileSize: MAX_UPLOAD_BYTES, files: 30, fields: 5 } });
    let folder = "";
    const saved = [];
    const pending = [];
    let failed = null;

    busboy.on("field", (name, value) => { if (name === "folder") folder = safeSegment(value); });
    busboy.on("file", (fieldName, stream, info) => {
      if (fieldName !== "photos") { stream.resume(); return; }
      const extension = path.extname(info.filename).toLowerCase();
      if (!IMAGE_EXTENSIONS.has(extension)) {
        stream.resume();
        failed = new Error("Only image files are allowed.");
        return;
      }
      const targetDir = path.join(galleryDir, folder);
      fs.mkdirSync(targetDir, { recursive: true });
      const target = path.join(targetDir, safeFileName(info.filename));
      const shouldNormalize = folder === "featured";
      const writeStream = fs.createWriteStream(target, { flags: "w" });
      let tooLarge = false;
      stream.on("limit", () => { tooLarge = true; failed = new Error("One image is larger than 12 MB."); });
      stream.pipe(writeStream);
      pending.push(new Promise((resolve, reject) => {
        writeStream.on("finish", async () => {
          if (tooLarge) {
            fs.rmSync(target, { force: true });
          } else {
            try {
              if (shouldNormalize) await normalizeFeaturedImage(target, extension);
              saved.push({ name: path.basename(target), path: path.relative(galleryDir, target), url: publicImagePath(path.relative(galleryDir, target)) });
            } catch (error) {
              fs.rmSync(target, { force: true });
              failed = new Error(`Featured image processing failed: ${error.message}`);
            }
          }
          resolve();
        });
        writeStream.on("error", reject);
        stream.on("error", reject);
      }));
    });
    busboy.on("error", (error) => { failed = error; });
    busboy.on("finish", async () => {
      try {
        await Promise.all(pending);
        if (failed) { sendJson(response, 400, { ok: false, message: failed.message }); return; }
        sendJson(response, 201, { ok: true, files: saved, ...scanGallery() });
      } catch (error) {
        sendJson(response, 500, { ok: false, message: error.message });
      }
    });
    request.pipe(busboy);
  }

  async function handle(request, response) {
    const url = new URL(request.url, "http://localhost");
    const pathname = url.pathname;

    if (pathname === "/api/master/login" && request.method === "POST") {
      try {
        const data = await parseJsonBody(request);
        const credentials = readCredentials(masterDir);
        if (String(data.id || "") !== credentials.id || String(data.password || "") !== credentials.password) {
          sendJson(response, 401, { ok: false, message: "Invalid master ID or password." });
          return true;
        }
        const token = crypto.randomBytes(32).toString("hex");
        sessions.set(token, Date.now() + SESSION_TTL_MS);
        response.writeHead(200, {
          "Content-Type": "application/json; charset=utf-8",
          "Cache-Control": "no-store",
          "Set-Cookie": `master_session=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${SESSION_TTL_MS / 1000}`,
        });
        response.end(JSON.stringify({ ok: true }));
      } catch (error) { sendJson(response, 400, { ok: false, message: error.message }); }
      return true;
    }

    if (pathname === "/api/master/logout" && request.method === "POST") {
      const token = parseCookies(request).master_session;
      if (token) sessions.delete(token);
      response.writeHead(200, { "Content-Type": "application/json; charset=utf-8", "Set-Cookie": "master_session=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0" });
      response.end(JSON.stringify({ ok: true }));
      return true;
    }

    if (pathname.startsWith("/api/master/") && !isAuthenticated(request)) {
      sendJson(response, 401, { ok: false, message: "Master login required." });
      return true;
    }

    if (pathname === "/api/master/status" && request.method === "GET") { sendJson(response, 200, { ok: true }); return true; }
    if (pathname === "/api/master/gallery" && request.method === "GET") { sendJson(response, 200, { ok: true, ...scanGallery() }); return true; }

    if (pathname === "/api/master/folders" && request.method === "POST") {
      try {
        const data = await parseJsonBody(request);
        const folder = safeSegment(data.folder);
        if (!folder) { sendJson(response, 400, { ok: false, message: "Enter a folder name." }); return true; }
        fs.mkdirSync(path.join(galleryDir, folder), { recursive: true });
        sendJson(response, 201, { ok: true, folder });
      } catch (error) { sendJson(response, 400, { ok: false, message: error.message }); }
      return true;
    }

    if (pathname === "/api/master/upload" && request.method === "POST") { await upload(request, response); return true; }

    if (pathname === "/api/master/images" && request.method === "DELETE") {
      const target = safeGalleryPath(url.searchParams.get("path"));
      if (!target || !fs.existsSync(target) || !fs.statSync(target).isFile()) { sendJson(response, 404, { ok: false, message: "Image not found." }); return true; }
      fs.rmSync(target);
      sendJson(response, 200, { ok: true });
      return true;
    }

    if (pathname.startsWith("/gallery-assets/") && request.method === "GET") {
      const target = safeGalleryPath(pathname.slice("/gallery-assets/".length));
      if (!target || !fs.existsSync(target) || !fs.statSync(target).isFile()) { response.writeHead(404); response.end("Not found"); return true; }
      response.writeHead(200, { "Content-Type": `image/${path.extname(target).slice(1).replace("jpg", "jpeg")}`, "Cache-Control": "public, max-age=3600" });
      fs.createReadStream(target).pipe(response);
      return true;
    }

    if (pathname === "/api/gallery" && request.method === "GET") { sendJson(response, 200, { ok: true, images: scanGallery().images }); return true; }
    return false;
  }

  return { handle, galleryDir, masterDir };
}

export { createMasterGallery };
